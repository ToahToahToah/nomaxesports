import { createClient } from "jsr:@supabase/supabase-js@2";
import { corsHeaders } from "jsr:@supabase/supabase-js@2/cors";
import { z } from "npm:zod@3.23.8";

const RECIPIENT = "noahfernandezhaddad@gmail.com";

const TryoutSchema = z.object({
  email: z.string().email().max(255),
  age: z.coerce.number().int().min(13).max(99),
  rank: z.string().min(1).max(50),
  rl_tracker: z.string().url().max(500),
  teammates: z.string().max(1000).optional().nullable(),
});
const PartnerSchema = z.object({
  email: z.string().email().max(255),
  website: z.string().url().max(500),
  reason: z.string().min(1).max(2000),
});
const BodySchema = z.discriminatedUnion("type", [
  z.object({ type: z.literal("tryout"), payload: TryoutSchema }),
  z.object({ type: z.literal("partner"), payload: PartnerSchema }),
]);

function escape(s: string | null | undefined) {
  return String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!));
}

function renderTryout(p: z.infer<typeof TryoutSchema>) {
  return `
    <h2>New NOMAX Tryout Application</h2>
    <p><b>Email:</b> ${escape(p.email)}</p>
    <p><b>Age:</b> ${p.age}</p>
    <p><b>Rank:</b> ${escape(p.rank)}</p>
    <p><b>RL Tracker:</b> <a href="${escape(p.rl_tracker)}">${escape(p.rl_tracker)}</a></p>
    <p><b>Teammates:</b><br/>${escape(p.teammates || "(none — wants to be matched)").replace(/\n/g, "<br/>")}</p>
  `;
}
function renderPartner(p: z.infer<typeof PartnerSchema>) {
  return `
    <h2>New NOMAX Partnership Inquiry</h2>
    <p><b>Email:</b> ${escape(p.email)}</p>
    <p><b>Website:</b> <a href="${escape(p.website)}">${escape(p.website)}</a></p>
    <p><b>Why partner:</b><br/>${escape(p.reason).replace(/\n/g, "<br/>")}</p>
  `;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const parsed = BodySchema.safeParse(await req.json());
    if (!parsed.success) {
      return new Response(JSON.stringify({ error: parsed.error.flatten() }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const { type, payload } = parsed.data;
    const subject = type === "tryout" ? "New NOMAX Tryout Application" : "New NOMAX Partnership Inquiry";
    const html = type === "tryout" ? renderTryout(payload) : renderPartner(payload);

    const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

    // Enqueue via Lovable Emails queue if available
    const { error } = await supabase.rpc("enqueue_email", {
      queue_name: "transactional_emails",
      payload: {
        to: RECIPIENT,
        reply_to: payload.email,
        subject,
        html,
        purpose: "transactional",
        template_name: type === "tryout" ? "tryout_application" : "partner_application",
      },
    });

    if (error) {
      console.error("enqueue_email failed:", error);
      return new Response(JSON.stringify({ ok: false, queued: false, error: error.message }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    return new Response(JSON.stringify({ ok: true, queued: true }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (e) {
    console.error(e);
    return new Response(JSON.stringify({ ok: false, error: String(e) }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});