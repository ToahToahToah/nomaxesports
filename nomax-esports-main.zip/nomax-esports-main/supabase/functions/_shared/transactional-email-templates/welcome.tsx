/// <reference types="npm:@types/react@18.3.1" />
import * as React from 'npm:react@18.3.1'
import {
  Body, Button, Container, Head, Heading, Html, Preview, Text,
} from 'npm:@react-email/components@0.0.22'
import type { TemplateEntry } from './registry.ts'

const SITE_NAME = 'NOMAX Esports'
const SITE_URL = 'https://nomax.team'

interface Props { name?: string }

const Welcome = ({ name }: Props) => (
  <Html lang="en" dir="ltr">
    <Head />
    <Preview>Welcome to {SITE_NAME}</Preview>
    <Body style={main}>
      <Container style={container}>
        <Heading style={h1}>{name ? `Welcome, ${name}` : 'Welcome'}</Heading>
        <Text style={text}>
          You're now part of the {SITE_NAME} community. Stay sharp — news,
          matches and updates land straight in your inbox.
        </Text>
        <Button style={button} href={SITE_URL}>Enter the arena</Button>
        <Text style={footer}>GG — The {SITE_NAME} team</Text>
      </Container>
    </Body>
  </Html>
)

export const template = {
  component: Welcome,
  subject: 'Welcome to NOMAX Esports',
  displayName: 'Welcome',
  previewData: { name: 'Player' },
} satisfies TemplateEntry

const main = { backgroundColor: '#ffffff', fontFamily: 'Rajdhani, Arial, sans-serif' }
const container = { padding: '24px 28px', maxWidth: '560px' }
const h1 = {
  fontSize: '26px', fontWeight: 'bold' as const, color: '#0a0a0a',
  fontFamily: 'Orbitron, Arial, sans-serif',
  textTransform: 'uppercase' as const, letterSpacing: '0.06em', margin: '0 0 20px',
}
const text = { fontSize: '15px', color: '#3f4148', lineHeight: '1.6', margin: '0 0 24px' }
const button = {
  backgroundColor: '#00e6c2', color: '#0a0a0a', fontSize: '14px',
  fontWeight: 'bold' as const, textTransform: 'uppercase' as const,
  letterSpacing: '0.08em', borderRadius: '4px', padding: '12px 22px',
  textDecoration: 'none',
}
const footer = { fontSize: '12px', color: '#999999', margin: '32px 0 0' }