/// <reference types="npm:@types/react@18.3.1" />
import * as React from 'npm:react@18.3.1'
import {
  Body, Button, Container, Head, Heading, Html, Preview, Text,
} from 'npm:@react-email/components@0.0.22'
import type { TemplateEntry } from './registry.ts'

const SITE_NAME = 'NOMAX Esports'
const SITE_URL = 'https://nomax.team'

const PartnerConfirmation = () => (
  <Html lang="en" dir="ltr">
    <Head />
    <Preview>Thanks for reaching out to NOMAX</Preview>
    <Body style={main}>
      <Container style={container}>
        <Heading style={h1}>Partnership inquiry received</Heading>
        <Text style={text}>
          Thanks for your interest in partnering with {SITE_NAME}. Our team will
          review your inquiry and follow up directly if there's a fit.
        </Text>
        <Button style={button} href={SITE_URL}>Visit nomax.team</Button>
        <Text style={footer}>The {SITE_NAME} team</Text>
      </Container>
    </Body>
  </Html>
)

export const template = {
  component: PartnerConfirmation,
  subject: 'Your NOMAX partnership inquiry',
  displayName: 'Partner confirmation',
  previewData: {},
} satisfies TemplateEntry

const main = { backgroundColor: '#ffffff', fontFamily: 'Rajdhani, Arial, sans-serif' }
const container = { padding: '24px 28px', maxWidth: '560px' }
const h1 = {
  fontSize: '24px', fontWeight: 'bold' as const, color: '#0a0a0a',
  fontFamily: 'Orbitron, Arial, sans-serif',
  textTransform: 'uppercase' as const, letterSpacing: '0.06em', margin: '0 0 20px',
}
const text = { fontSize: '15px', color: '#3f4148', lineHeight: '1.6', margin: '0 0 24px' }
const button = {
  backgroundColor: '#00e6c2', color: '#0a0a0a', fontSize: '14px',
  fontWeight: 'bold' as const, textTransform: 'uppercase' as const,
  letterSpacing: '0.08em', borderRadius: '4px', padding: '12px 22px',
  textDecoration: 'none',
}
const footer = { fontSize: '12px', color: '#999999', margin: '32px 0 0' }