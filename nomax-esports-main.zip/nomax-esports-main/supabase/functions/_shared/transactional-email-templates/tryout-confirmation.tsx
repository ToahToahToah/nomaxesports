/// <reference types="npm:@types/react@18.3.1" />
import * as React from 'npm:react@18.3.1'
import {
  Body, Button, Container, Head, Heading, Html, Preview, Section, Text,
} from 'npm:@react-email/components@0.0.22'
import type { TemplateEntry } from './registry.ts'

const SITE_NAME = 'NOMAX Esports'
const SITE_URL = 'https://nomax.team'

interface Props {
  rank?: string
  rl_tracker?: string
}

const TryoutConfirmation = ({ rank, rl_tracker }: Props) => (
  <Html lang="en" dir="ltr">
    <Head />
    <Preview>We received your NOMAX tryout application</Preview>
    <Body style={main}>
      <Container style={container}>
        <Heading style={h1}>Tryout received</Heading>
        <Text style={text}>
          Thanks for applying to try out for {SITE_NAME}. Our staff will review
          your application and reach out if you move forward to the next stage.
        </Text>
        {(rank || rl_tracker) && (
          <Section style={card}>
            {rank && <Text style={detail}><strong>Rank:</strong> {rank}</Text>}
            {rl_tracker && <Text style={detail}><strong>Tracker:</strong> {rl_tracker}</Text>}
          </Section>
        )}
        <Button style={button} href={SITE_URL}>Visit nomax.team</Button>
        <Text style={footer}>GG — The {SITE_NAME} staff</Text>
      </Container>
    </Body>
  </Html>
)

export const template = {
  component: TryoutConfirmation,
  subject: 'Your NOMAX tryout application',
  displayName: 'Tryout confirmation',
  previewData: { rank: 'Grand Champion II', rl_tracker: 'https://rocketleague.tracker.network/...' },
} satisfies TemplateEntry

const main = { backgroundColor: '#ffffff', fontFamily: 'Rajdhani, Arial, sans-serif' }
const container = { padding: '24px 28px', maxWidth: '560px' }
const h1 = {
  fontSize: '24px', fontWeight: 'bold' as const, color: '#0a0a0a',
  fontFamily: 'Orbitron, Arial, sans-serif',
  textTransform: 'uppercase' as const, letterSpacing: '0.06em', margin: '0 0 20px',
}
const text = { fontSize: '15px', color: '#3f4148', lineHeight: '1.6', margin: '0 0 20px' }
const card = {
  backgroundColor: '#0a0a0a', color: '#ffffff', padding: '16px 18px',
  borderRadius: '6px', margin: '0 0 24px', borderLeft: '3px solid #00e6c2',
}
const detail = { fontSize: '14px', color: '#ffffff', margin: '4px 0' }
const button = {
  backgroundColor: '#00e6c2', color: '#0a0a0a', fontSize: '14px',
  fontWeight: 'bold' as const, textTransform: 'uppercase' as const,
  letterSpacing: '0.08em', borderRadius: '4px', padding: '12px 22px',
  textDecoration: 'none',
}
const footer = { fontSize: '12px', color: '#999999', margin: '32px 0 0' }