ALTER TABLE public.player_room_messages
ADD COLUMN IF NOT EXISTS game text NOT NULL DEFAULT 'rocket_league';

CREATE INDEX IF NOT EXISTS idx_player_room_messages_game_created
ON public.player_room_messages (game, created_at);