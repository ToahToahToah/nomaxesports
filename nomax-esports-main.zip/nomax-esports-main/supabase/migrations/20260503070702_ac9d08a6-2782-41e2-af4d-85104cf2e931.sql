
CREATE TABLE public.tryout_applications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT NOT NULL,
  age INTEGER NOT NULL,
  rank TEXT NOT NULL,
  rl_tracker TEXT NOT NULL,
  teammates TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.partner_applications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT NOT NULL,
  website TEXT NOT NULL,
  reason TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.tryout_applications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.partner_applications ENABLE ROW LEVEL SECURITY;

-- Anyone can submit (public forms), but no one can read (sensitive applicant data)
CREATE POLICY "Anyone can submit tryouts" ON public.tryout_applications
  FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can submit partner inquiries" ON public.partner_applications
  FOR INSERT WITH CHECK (true);
