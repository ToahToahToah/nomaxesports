CREATE TABLE public.player_room_messages (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  author text NOT NULL,
  content text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.player_room_messages ENABLE ROW LEVEL SECURITY;

-- Player room is gated by a shared client-side code. Anyone who knows the code
-- can read/post in the room, so policies are intentionally public.
CREATE POLICY "Anyone can read player room messages"
ON public.player_room_messages FOR SELECT
USING (true);

CREATE POLICY "Anyone can post player room messages"
ON public.player_room_messages FOR INSERT
WITH CHECK (
  length(trim(author)) BETWEEN 1 AND 40
  AND length(trim(content)) BETWEEN 1 AND 500
);

CREATE INDEX player_room_messages_created_at_idx
  ON public.player_room_messages (created_at DESC);

ALTER PUBLICATION supabase_realtime ADD TABLE public.player_room_messages;
ALTER TABLE public.player_room_messages REPLICA IDENTITY FULL;