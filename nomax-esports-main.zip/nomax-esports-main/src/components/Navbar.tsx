import { useState } from "react";
import { NavLink, Link } from "react-router-dom";
import { Menu, X, Twitter, Youtube, Twitch } from "lucide-react";
import { DiscordIcon } from "@/components/icons/DiscordIcon";
import { TikTokIcon } from "@/components/icons/TikTokIcon";
import { cn } from "@/lib/utils";

const internalLinks = [
  { to: "/", label: "Home" },
  { to: "/roster", label: "Roster" },
  { to: "/schedule", label: "Schedule" },
  { to: "/merch", label: "Merch", external: "https://merch.nomax.team" },
  { to: "/about", label: "About" },
  { to: "/coach", label: "Coach", external: "https://coach.nomax.team" },
  { to: "/assistant", label: "Assistant", external: "https://assistant.nomax.team" },
];

const socials = [
  { href: "https://x.com/NomaxEsports", label: "X", Icon: Twitter },
  { href: "https://www.youtube.com/@NomaxEsports", label: "YouTube", Icon: Youtube },
  { href: "https://www.twitch.tv/nomaxesports", label: "Twitch", Icon: Twitch },
  { href: "https://www.tiktok.com/@nomaxesports", label: "TikTok", Icon: TikTokIcon },
  { href: "https://discord.gg/g8YvazAbpx", label: "Discord", Icon: DiscordIcon },
];

export const Navbar = () => {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-50 backdrop-blur-xl bg-background/80 border-b border-border">
      <div className="container flex items-center justify-between h-16">
        <Link to="/" className="font-display font-black text-xl tracking-widest">
          <span className="text-foreground">NO</span>
          <span className="text-neon-blue text-glow-blue">MAX</span>
          <span className="text-muted-foreground text-xs ml-2 font-sans tracking-[0.3em]">ESPORTS</span>
        </Link>
        <nav className="hidden md:flex items-center gap-1">
          {internalLinks.map((l) => l.external ? (
            <a
              key={l.to}
              href={l.external}
              target="_blank"
              rel="noreferrer"
              className="px-4 py-2 text-sm font-semibold uppercase tracking-wider transition-colors text-foreground/80 hover:text-neon-blue"
            >
              {l.label}
            </a>
          ) : (
            <NavLink
              key={l.to}
              to={l.to}
              end={l.to === "/"}
              className={({ isActive }) =>
                cn(
                  "px-4 py-2 text-sm font-semibold uppercase tracking-wider transition-colors relative",
                  isActive ? "text-neon-blue" : "text-foreground/80 hover:text-neon-blue"
                )
              }
            >
              {({ isActive }) => (
                <>
                  {l.label}
                  {isActive && <span className="absolute left-2 right-2 -bottom-0.5 h-px bg-neon-blue shadow-neon-blue" />}
                </>
              )}
            </NavLink>
          ))}
        </nav>
        <div className="hidden md:flex items-center gap-1 ml-3 pl-3 border-l border-border">
          {socials.map(({ href, label, Icon }) => (
            <a
              key={label}
              href={href}
              target="_blank"
              rel="noreferrer"
              aria-label={label}
              className="w-9 h-9 grid place-items-center text-foreground/70 hover:text-neon-blue hover:shadow-neon-blue clip-corner transition-all"
            >
              <Icon className="w-4 h-4" />
            </a>
          ))}
        </div>
        <button onClick={() => setOpen(!open)} className="md:hidden p-2 text-foreground" aria-label="Menu">
          {open ? <X /> : <Menu />}
        </button>
      </div>
      {open && (
        <nav className="md:hidden border-t border-border bg-background/95">
          <div className="container py-4 flex flex-col gap-1">
            {internalLinks.map((l) => l.external ? (
              <a
                key={l.to}
                href={l.external}
                target="_blank"
                rel="noreferrer"
                onClick={() => setOpen(false)}
                className="px-4 py-3 text-sm font-semibold uppercase tracking-wider text-foreground/80"
              >
                {l.label}
              </a>
            ) : (
              <NavLink
                key={l.to}
                to={l.to}
                end={l.to === "/"}
                onClick={() => setOpen(false)}
                className={({ isActive }) =>
                  cn(
                    "px-4 py-3 text-sm font-semibold uppercase tracking-wider",
                    isActive ? "text-neon-blue" : "text-foreground/80"
                  )
                }
              >
                {l.label}
              </NavLink>
            ))}
            <div className="flex items-center gap-2 px-4 pt-3 border-t border-border mt-2">
              {socials.map(({ href, label, Icon }) => (
                <a key={label} href={href} target="_blank" rel="noreferrer" aria-label={label}
                  className="w-10 h-10 grid place-items-center border border-border text-foreground/80 hover:text-neon-blue hover:border-neon-blue clip-corner">
                  <Icon className="w-4 h-4" />
                </a>
              ))}
            </div>
          </div>
        </nav>
      )}
    </header>
  );
};
