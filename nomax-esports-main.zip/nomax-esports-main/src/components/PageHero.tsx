interface Props { eyebrow: string; title: string; description?: string; }
export const PageHero = ({ eyebrow, title, description }: Props) => (
  <section className="relative overflow-hidden border-b border-border">
    <div className="absolute inset-0 opacity-30 pointer-events-none"
      style={{ background: "radial-gradient(ellipse at 30% 50%, hsl(var(--neon-blue) / 0.25), transparent 60%), radial-gradient(ellipse at 70% 50%, hsl(var(--neon-orange) / 0.15), transparent 60%)" }} />
    <div className="container relative py-20 md:py-28">
      <div className="text-neon-orange uppercase tracking-[0.4em] text-xs font-semibold mb-4">// {eyebrow}</div>
      <h1 className="font-display text-5xl md:text-7xl font-black uppercase tracking-tight">{title}</h1>
      {description && <p className="mt-6 text-lg text-muted-foreground max-w-2xl">{description}</p>}
    </div>
  </section>
);
