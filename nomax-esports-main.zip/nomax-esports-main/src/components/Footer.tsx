import { Link } from "react-router-dom";
import { Youtube, Twitch, Twitter } from "lucide-react";
import { DiscordIcon } from "@/components/icons/DiscordIcon";
import { TikTokIcon } from "@/components/icons/TikTokIcon";

export const Footer = () => (
  <footer className="border-t border-border mt-24 bg-background/60">
    <div className="container py-12 grid gap-8 md:grid-cols-3">
      <div>
        <div className="font-display font-black text-2xl tracking-widest">
          NO<span className="text-neon-blue text-glow-blue">MAX</span>
        </div>
        <p className="mt-3 text-sm text-muted-foreground max-w-xs">
          Rocket League esports organization based in Spain. Compete. Create. Dominate.
        </p>
      </div>
      <div className="flex flex-col gap-2 text-sm">
        <h4 className="font-display text-neon-orange uppercase tracking-widest text-xs mb-2">Navigate</h4>
        {[
          ["/", "Home"],
          ["/roster", "Roster"],
          ["/partners", "Partners"],
          ["/assistant", "Assistant"],
          ["/about", "About"],
          ["/support", "Support Us"],
          ["/contact", "Contact"],
        ].map(([to, label]) => (
          <Link key={to} to={to} className="text-foreground/70 hover:text-neon-blue w-fit">
            {label}
          </Link>
        ))}
        <a
          href="https://merch.nomax.team"
          target="_blank"
          rel="noreferrer"
          className="text-foreground/70 hover:text-neon-blue w-fit"
        >
          Shop
        </a>
      </div>
      <div>
        <h4 className="font-display text-neon-orange uppercase tracking-widest text-xs mb-3">Follow</h4>
        <div className="flex gap-3">
          {[
            { Icon: Youtube, label: "YouTube", href: "https://www.youtube.com/@NomaxEsports" },
            { Icon: Twitch, label: "Twitch", href: "https://www.twitch.tv/nomaxesports" },
            { Icon: Twitter, label: "X", href: "https://x.com/NomaxEsports" },
            { Icon: TikTokIcon, label: "TikTok", href: "https://www.tiktok.com/@nomaxesports" },
            { Icon: DiscordIcon, label: "Discord", href: "https://discord.gg/SzYJCFkCPZ" },
          ].map(({ Icon, label, href }) => (
            <a
              key={label}
              href={href}
              target="_blank"
              rel="noreferrer"
              aria-label={label}
              className="w-10 h-10 grid place-items-center border border-border hover:border-neon-blue hover:text-neon-blue transition-colors clip-corner"
            >
              <Icon className="w-4 h-4" />
            </a>
          ))}
        </div>
        <p className="mt-6 text-xs text-muted-foreground">
          Powered by <span className="text-foreground font-semibold">NOMAX 3D Printing</span> ·{" "}
          <a href="https://nomax.team" className="text-neon-blue hover:underline">
            nomax.team
          </a>
        </p>
      </div>
    </div>
    <div className="border-t border-border">
      <div className="container py-4 text-xs text-muted-foreground flex justify-between">
        <span>© 2026 NOMAX Esports. All rights reserved.</span>
        <span className="hidden md:inline tracking-widest uppercase">SYS · ONLINE</span>
      </div>
    </div>
  </footer>
);
