interface Props { eyebrow?: string; title: string; subtitle?: string; align?: "left" | "center"; }
export const SectionHeader = ({ eyebrow, title, subtitle, align = "center" }: Props) => (
  <div className={align === "center" ? "text-center max-w-3xl mx-auto mb-12" : "max-w-3xl mb-12"}>
    {eyebrow && (
      <div className={`flex items-center gap-3 ${align === "center" ? "justify-center" : ""} mb-3`}>
        <span className="h-px w-8 bg-neon-orange" />
        <span className="text-neon-orange uppercase tracking-[0.3em] text-xs font-semibold">{eyebrow}</span>
        <span className="h-px w-8 bg-neon-orange" />
      </div>
    )}
    <h2 className="font-display text-3xl md:text-5xl font-black uppercase tracking-tight">{title}</h2>
    {subtitle && <p className="mt-4 text-muted-foreground text-lg">{subtitle}</p>}
  </div>
);
