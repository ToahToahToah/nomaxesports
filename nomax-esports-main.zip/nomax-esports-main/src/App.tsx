import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Index from "./pages/Index.tsx";
import NotFound from "./pages/NotFound.tsx";
import Roster from "./pages/Roster.tsx";
import Partners from "./pages/Partners.tsx";
import About from "./pages/About.tsx";
import Contact from "./pages/Contact.tsx";
import Tryouts from "./pages/Tryouts.tsx";
import PartnerApply from "./pages/PartnerApply.tsx";
import News from "./pages/News.tsx";
import Coaching from "./pages/Coaching.tsx";
import Support from "./pages/Support.tsx";
import Schedule from "./pages/Schedule.tsx";
import Unsubscribe from "./pages/Unsubscribe.tsx";
import Assistant from "./pages/Assistant.tsx";
import PlayerRoom from "./pages/PlayerRoom.tsx";
import { Layout } from "./components/Layout.tsx";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route element={<Layout />}>
            <Route path="/" element={<Index />} />
            <Route path="/roster" element={<Roster />} />
            <Route path="/partners" element={<Partners />} />
            <Route path="/about" element={<About />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/tryouts" element={<Tryouts />} />
            <Route path="/partner-apply" element={<PartnerApply />} />
            <Route path="/news" element={<News />} />
            <Route path="/coaching" element={<Coaching />} />
            <Route path="/support" element={<Support />} />
            <Route path="/schedule" element={<Schedule />} />
            <Route path="/unsubscribe" element={<Unsubscribe />} />
            <Route path="/assistant" element={<Assistant />} />
            <Route path="/player-room" element={<PlayerRoom />} />
            <Route path="*" element={<NotFound />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
