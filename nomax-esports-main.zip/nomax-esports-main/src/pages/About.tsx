import { Link } from "react-router-dom";
import { Users, Cpu, Trophy, Printer, Target, Rocket, ArrowRight } from "lucide-react";
import { PageHero } from "@/components/PageHero";
import { Seo } from "@/components/Seo";

const values = [
  { icon: Users, title: "Community", desc: "Bridging grassroots talent with the competitive scene. Players first, always." },
  { icon: Cpu, title: "Innovation", desc: "Born from a 3D printing brand — building gear, content and ideas you cannot find anywhere else." },
  { icon: Trophy, title: "Performance", desc: "Disciplined practice, structured coaching, and the relentless pursuit of the next rank." },
];

const About = () => (
  <>
    <Seo
      title="About NOMAX Esports — Our Story & Mission"
      description="Learn how NOMAX Esports bridges Spanish Rocket League grassroots talent with competitive play, backed by NOMAX 3D Printing."
      path="/about"
    />
    <PageHero
      eyebrow="The Story"
      title="About NOMAX"
      description="A serious, long-term Rocket League organization powered by NOMAX 3D Printing."
    />
    <section className="container py-16">
      <div className="grid lg:grid-cols-3 gap-10">
        <div className="lg:col-span-2 space-y-6 text-lg text-foreground/80 leading-relaxed">
          <div>
            <div className="text-neon-blue uppercase tracking-[0.3em] text-xs font-semibold mb-3">// Who We Are</div>
            <p>
              NOMAX Esports is a Rocket League organization built for the long game. We are Spanish-rooted, EU-focused, and obsessed with developing competitive talent the right way — from GC1 grinders to the open circuit.
            </p>
          </div>
          <div>
            <div className="text-neon-blue uppercase tracking-[0.3em] text-xs font-semibold mb-3">// Powered by NOMAX 3D Printing</div>
            <p>
              We are backed by <span className="text-foreground font-semibold">NOMAX 3D Printing</span> — a Spanish brand that designs and manufactures custom gaming gear and accessories. That means real engineering, real funding, and a roster that is not just sponsored — it is <span className="text-neon-blue font-semibold">built</span>.
            </p>
          </div>
          <div>
            <div className="text-neon-blue uppercase tracking-[0.3em] text-xs font-semibold mb-3">// Our Goal</div>
            <p>
              Build a serious, long-term Rocket League organization. Not a hype project. Not a one-season experiment. A real home for players, coaches and partners who want to grow with us across multiple seasons.
            </p>
          </div>
        </div>
        <aside className="space-y-4">
          {[
            { icon: Printer, label: "Backed By", value: "NOMAX 3D Printing" },
            { icon: Rocket, label: "Game", value: "Rocket League" },
            { icon: Target, label: "Region", value: "EU · Spain" },
            { icon: Trophy, label: "Vision", value: "Long-term competitive org" },
          ].map((s) => (
            <div key={s.label} className="flex items-start gap-4 bg-card border border-border clip-corner p-5">
              <s.icon className="w-6 h-6 text-neon-blue mt-0.5" />
              <div>
                <div className="text-[10px] uppercase tracking-widest text-muted-foreground">{s.label}</div>
                <div className="font-display font-bold uppercase tracking-wider mt-1">{s.value}</div>
              </div>
            </div>
          ))}
        </aside>
      </div>

      <div className="mt-20 grid md:grid-cols-3 gap-6">
        {values.map((v) => (
          <div key={v.title} className="bg-card border border-border clip-corner p-8 hover:border-neon-blue transition-colors">
            <v.icon className="w-10 h-10 text-neon-blue" />
            <h3 className="font-display text-2xl font-black uppercase mt-5 tracking-wider">{v.title}</h3>
            <p className="mt-3 text-muted-foreground">{v.desc}</p>
          </div>
        ))}
      </div>

      <div className="mt-20 flex flex-wrap justify-center gap-3">
        <Link to="/roster" className="btn-neon inline-flex items-center gap-2 px-7 py-4 font-display font-bold uppercase tracking-widest text-xs clip-corner">
          See the Roster <ArrowRight className="w-4 h-4" />
        </Link>
        <Link to="/support" className="btn-ghost-neon inline-flex items-center gap-2 px-7 py-4 font-display font-bold uppercase tracking-widest text-xs clip-corner">
          Support the Team <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
    </section>
  </>
);

export default About;
