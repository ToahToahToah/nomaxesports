import productImg from "@/assets/product-placeholder.jpg";
import { PageHero } from "@/components/PageHero";
import { SectionHeader } from "@/components/SectionHeader";
import { ExternalLink } from "lucide-react";

const sections = [
  {
    key: "3D Prints",
    items: [
      { name: "Custom Controller Mod", price: "TBD", external: "https://nomax.store" },
      { name: "Mini Rocket Trophy", price: "TBD", external: "https://nomax.store" },
      { name: "Desk Plate — NOMAX", price: "TBD", external: "https://nomax.store" },
    ],
  },
  {
    key: "Apparel",
    items: [
      { name: "Pro Jersey 2026", price: "TBD" },
      { name: "Tech Hoodie", price: "TBD" },
      { name: "Training Tee", price: "TBD" },
    ],
  },
  {
    key: "Accessories",
    items: [
      { name: "Mousepad XL", price: "TBD" },
      { name: "Snapback Cap", price: "TBD" },
      { name: "Sticker Pack", price: "TBD" },
    ],
  },
];

const Shop = () => (
  <>
    <PageHero
      eyebrow="Gear Up"
      title="The Shop"
      description="3D prints, apparel and accessories — built for the squad and the fans."
    />
    <section className="container py-16 space-y-20">
      {sections.map((sec) => (
        <div key={sec.key}>
          <SectionHeader eyebrow="Collection" title={sec.key} align="left" />
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {sec.items.map((it) => (
              <article
                key={it.name}
                className="group bg-card border border-border clip-corner overflow-hidden hover:border-neon-blue transition-all"
              >
                <div className="aspect-square overflow-hidden border-b border-border">
                  <img
                    src={productImg}
                    alt={it.name}
                    loading="lazy"
                    width={800}
                    height={800}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                </div>
                <div className="p-5">
                  <h3 className="font-display text-lg font-bold uppercase tracking-wider">{it.name}</h3>
                  <div className="mt-1 text-sm text-muted-foreground">
                    Price: <span className="text-neon-orange font-semibold">{it.price}</span>
                  </div>
                  {it.external ? (
                    <a
                      href={it.external}
                      target="_blank"
                      rel="noreferrer"
                      className="mt-4 w-full inline-flex items-center justify-center gap-2 bg-neon-blue text-primary-foreground px-4 py-2.5 font-display font-bold uppercase tracking-widest text-xs clip-corner hover:bg-neon-orange transition-colors"
                    >
                      Buy Now <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  ) : (
                    <button className="mt-4 w-full bg-neon-blue text-primary-foreground px-4 py-2.5 font-display font-bold uppercase tracking-widest text-xs clip-corner hover:bg-neon-orange transition-colors">
                      Buy Now
                    </button>
                  )}
                </div>
              </article>
            ))}
          </div>
        </div>
      ))}

      <div className="relative bg-card border border-border clip-corner p-8 md:p-10 text-center overflow-hidden">
        <div className="absolute inset-0 opacity-20" style={{ background: "var(--gradient-glow)" }} />
        <p className="relative font-display text-lg md:text-xl uppercase tracking-wider">
          All 3D printed merch powered by <span className="text-neon-blue text-glow-blue">NOMAX</span> — visit{" "}
          <a href="https://nomax.store" className="text-neon-orange hover:underline">
            nomax.store
          </a>
        </p>
      </div>
    </section>
  </>
);

export default Shop;
