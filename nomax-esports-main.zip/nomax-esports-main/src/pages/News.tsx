import { Calendar, Trophy, UserPlus, Megaphone } from "lucide-react";
import { PageHero } from "@/components/PageHero";

type Category = "Signing" | "Tournament" | "Announcement";

const iconFor: Record<Category, typeof Trophy> = {
  Signing: UserPlus,
  Tournament: Trophy,
  Announcement: Megaphone,
};

const posts: { date: string; category: Category; title: string; body: string }[] = [
  {
    date: "May 2026",
    category: "Announcement",
    title: "NOMAX Esports launches",
    body: "Born from the NOMAX 3D printing brand, our esports division opens its doors with a clear mission: build a Spanish-rooted Rocket League org that develops talent from GC1 all the way to SSL.",
  },
  {
    date: "Coming Soon",
    category: "Signing",
    title: "Team A — Roster reveal incoming",
    body: "We're closing tryouts for our flagship GC3-SSL squad. First signings will be announced here. Apply now to be in the conversation.",
  },
  {
    date: "Coming Soon",
    category: "Tournament",
    title: "First open circuit appearance",
    body: "NOMAX colors will hit the open circuit shortly after rosters lock. Tournament results, VODs and recaps will land in this feed.",
  },
];

const News = () => (
  <>
    <PageHero eyebrow="Newsfeed" title="News & Announcements" description="Signings, tournament results, drops and updates from inside the org." />
    <section className="container py-16">
      <div className="grid gap-6 max-w-3xl mx-auto">
        {posts.map((p, i) => {
          const Icon = iconFor[p.category];
          return (
            <article key={i} className="relative bg-card border border-border clip-corner p-6 md:p-8 hover:border-neon-blue transition-colors">
              <div className="flex items-center gap-3 text-xs uppercase tracking-widest text-muted-foreground mb-3">
                <span className="inline-flex items-center gap-2 text-neon-orange">
                  <Icon className="w-4 h-4" /> {p.category}
                </span>
                <span className="h-px flex-1 bg-border" />
                <span className="inline-flex items-center gap-1.5"><Calendar className="w-3.5 h-3.5" /> {p.date}</span>
              </div>
              <h2 className="font-display text-2xl md:text-3xl font-black uppercase tracking-wide">{p.title}</h2>
              <p className="mt-3 text-muted-foreground leading-relaxed">{p.body}</p>
            </article>
          );
        })}
      </div>
    </section>
  </>
);

export default News;