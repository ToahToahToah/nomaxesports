import { useEffect } from "react";

export default function Assistant() {
  useEffect(() => {
    window.location.replace("https://assistant.nomax.team");
  }, []);

  return (
    <div className="min-h-[50vh] flex items-center justify-center">
      <p className="text-muted-foreground">Redirecting to Assistant…</p>
    </div>
  );
}
