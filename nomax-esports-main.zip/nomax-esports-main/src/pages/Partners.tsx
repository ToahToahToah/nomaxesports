import { Link } from "react-router-dom";
import { ExternalLink, Plus, Handshake, TrendingUp, Eye, Trophy, ArrowRight } from "lucide-react";
import { PageHero } from "@/components/PageHero";
import { SectionHeader } from "@/components/SectionHeader";
import logo from "@/assets/nomax-logo.png";
import { Seo } from "@/components/Seo";

const tiers = [
  { tier: "Silver", perks: ["Logo on website", "Social shoutouts", "Quarterly highlight"] },
  { tier: "Gold", perks: ["Jersey placement", "Stream branding", "Co-branded content", "Priority placement"] },
  { tier: "Platinum", perks: ["Headline jersey spot", "Tournament naming rights", "Dedicated content series", "First refusal on renewals"] },
];

const benefits = [
  { icon: Eye, title: "Real Visibility", desc: "Stream overlays, jerseys, social and event placements across the EU Rocket League scene." },
  { icon: TrendingUp, title: "Growth Brand", desc: "Get in early with a fast-moving Spanish org powered by a real 3D printing business." },
  { icon: Trophy, title: "Competitive Roster", desc: "GC1+ EU talent across PC, PS5 and Xbox — built to perform on stage and on stream." },
];

const Partners = () => (
  <>
    <Seo
      title="Partners — NOMAX Esports"
      description="Meet the brands powering NOMAX Esports on and off the pitch, and learn how to become an official partner."
      path="/partners"
    />
    <PageHero eyebrow="Allies" title="Our Partners" description="The brands that power NOMAX Esports on and off the pitch." />
    <section className="container py-16">
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        <article className="md:col-span-2 lg:col-span-2 group relative bg-card border border-neon-blue/40 clip-corner p-8 overflow-hidden">
          <div className="absolute inset-0 opacity-20" style={{ background: "var(--gradient-glow)" }} />
          <div className="relative grid sm:grid-cols-[180px_1fr] gap-6 items-center">
            <div className="bg-background/60 border border-border p-4 grid place-items-center clip-corner">
              <img src={logo} alt="NOMAX" className="w-full h-auto" loading="lazy" width={1024} height={512} />
            </div>
            <div>
              <div className="text-neon-orange uppercase tracking-[0.3em] text-xs font-semibold mb-2">// Official 3D Printing Partner</div>
              <h3 className="font-display text-2xl md:text-3xl font-black uppercase">NOMAX</h3>
              <p className="mt-3 text-muted-foreground">Custom 3D printed gaming accessories and merch, powered by nomax.store.</p>
              <a href="https://nomax.store" target="_blank" rel="noreferrer" className="mt-5 inline-flex items-center gap-2 bg-neon-blue text-primary-foreground px-5 py-2.5 font-display font-bold uppercase tracking-widest text-xs clip-corner shadow-neon-blue hover:bg-neon-orange hover:shadow-neon-orange transition-all">
                Visit nomax.store <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        </article>

        {[0, 1, 2, 3].map((i) => (
          <article key={i} className="group bg-card/40 border border-dashed border-border clip-corner p-8 min-h-[220px] flex flex-col items-center justify-center text-center hover:border-neon-orange/60 transition-colors">
            <Plus className="w-10 h-10 text-muted-foreground group-hover:text-neon-orange transition-colors" />
            <div className="mt-3 font-display uppercase tracking-widest text-sm">Your Brand Here</div>
            <div className="text-xs text-muted-foreground mt-1">Slot available</div>
          </article>
        ))}
      </div>

      <div className="mt-16 text-center">
        <Link to="/partner-apply" className="btn-neon inline-flex items-center gap-2 px-8 py-4 font-display font-bold uppercase tracking-widest text-sm clip-corner">
          <Handshake className="w-4 h-4" /> Become a Partner
        </Link>
      </div>
    </section>

    <section className="container pb-16">
      <SectionHeader eyebrow="Why Partner" title="What You Get" />
      <div className="grid md:grid-cols-3 gap-6">
        {benefits.map((b) => (
          <div key={b.title} className="relative bg-card border border-border clip-corner p-8 overflow-hidden">
            <div className="absolute -top-16 -right-16 w-40 h-40 rounded-full opacity-20" style={{ background: "hsl(var(--neon-blue))", filter: "blur(60px)" }} />
            <b.icon className="w-9 h-9 text-neon-blue relative" />
            <h3 className="mt-5 font-display text-xl font-bold uppercase tracking-wider relative">{b.title}</h3>
            <p className="mt-3 text-muted-foreground relative">{b.desc}</p>
          </div>
        ))}
      </div>
    </section>

    <section className="container pb-20">
      <SectionHeader eyebrow="Tiers" title="Sponsorship Packages" />
      <div className="grid md:grid-cols-3 gap-6">
        {tiers.map((t, i) => (
          <div key={t.tier} className={`relative bg-card clip-corner p-8 border ${i === 1 ? "border-neon-blue/60 shadow-neon-blue" : "border-border"}`}>
            {i === 1 && <div className="absolute top-3 right-3 text-[10px] uppercase tracking-widest text-neon-blue border border-neon-blue/60 px-2 py-1 bg-background/70">Most Popular</div>}
            <div className="text-neon-blue uppercase tracking-[0.3em] text-xs font-semibold">// Tier</div>
            <h3 className="mt-2 font-display text-3xl font-black uppercase">{t.tier}</h3>
            <ul className="mt-6 space-y-3">
              {t.perks.map((p) => (
                <li key={p} className="flex items-start gap-2 text-foreground/85">
                  <span className="mt-2 w-1.5 h-1.5 bg-neon-blue rounded-full shrink-0" />
                  <span>{p}</span>
                </li>
              ))}
            </ul>
            <Link to="/partner-apply" className="mt-7 inline-flex items-center gap-2 text-xs uppercase tracking-widest font-bold text-neon-blue hover:text-glow-blue">
              Get in Touch <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        ))}
      </div>
    </section>

    <section className="container pb-24">
      <div className="relative bg-card border border-neon-blue/40 clip-corner p-10 md:p-16 overflow-hidden">
        <div className="absolute inset-0 opacity-25" style={{ background: "radial-gradient(circle at 80% 50%, hsl(var(--neon-blue) / 0.45), transparent 65%)" }} />
        <div className="relative grid md:grid-cols-[1fr_auto] gap-6 items-center">
          <div>
            <div className="text-neon-blue uppercase tracking-[0.3em] text-xs font-semibold mb-3">// Let's Build</div>
            <h3 className="font-display text-3xl md:text-4xl font-black uppercase">Put your brand <span className="text-neon-blue text-glow-blue">on the pitch.</span></h3>
            <p className="mt-3 text-muted-foreground max-w-xl">Tell us about your brand and goals. We'll come back with a tailored proposal in days, not weeks.</p>
          </div>
          <Link to="/partner-apply" className="btn-neon inline-flex items-center gap-2 px-8 py-4 font-display font-bold uppercase tracking-widest text-sm clip-corner">
            <Handshake className="w-4 h-4" /> Become a Partner
          </Link>
        </div>
      </div>
    </section>
  </>
);

export default Partners;
