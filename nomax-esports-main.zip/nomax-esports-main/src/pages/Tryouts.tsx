import { useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { Send, Trophy, Globe2, Gamepad2, Users } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { PageHero } from "@/components/PageHero";
import { Seo } from "@/components/Seo";

const schema = z.object({
  email: z.string().trim().email("Invalid email").max(255),
  age: z.coerce.number().int().min(13, "Must be 13+").max(99),
  region: z.string().trim().min(1).max(50),
  platform: z.enum(["PC", "PS5", "Xbox"], { errorMap: () => ({ message: "Platform required" }) }),
  role: z.enum(["Main Player", "Substitute", "Coach"], { errorMap: () => ({ message: "Role required" }) }),
  rank: z.string().trim().min(1, "Rank required").max(50),
  rl_tracker: z.string().trim().url("Must be a valid URL").max(500),
  teammates: z.string().trim().max(1000).optional(),
});

const inputCls =
  "w-full bg-input border border-border focus:border-neon-blue focus:outline-none px-4 py-3 text-foreground placeholder:text-muted-foreground transition-colors clip-corner";

const Tryouts = () => {
  const [form, setForm] = useState({
    email: "",
    age: "",
    region: "EU",
    platform: "PC" as "PC" | "PS5" | "Xbox",
    role: "Main Player" as "Main Player" | "Substitute" | "Coach",
    rank: "Grand Champion 1",
    rl_tracker: "",
    teammates: "",
  });
  const [submitting, setSubmitting] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = schema.safeParse(form);
    if (!parsed.success) {
      toast.error(parsed.error.issues[0].message);
      return;
    }
    setSubmitting(true);
    const { error: dbError } = await supabase.from("tryout_applications").insert({
      email: parsed.data.email,
      age: parsed.data.age,
      region: parsed.data.region,
      platform: parsed.data.platform,
      role: parsed.data.role,
      rank: parsed.data.rank,
      rl_tracker: parsed.data.rl_tracker,
      teammates: parsed.data.teammates || null,
    });
    if (dbError) {
      toast.error("Could not submit. Try again.");
      setSubmitting(false);
      return;
    }
    await supabase.functions.invoke("send-application-email", {
      body: { type: "tryout", payload: parsed.data },
    });
    toast.success("Application received. We'll be in touch.");
    setForm({
      email: "",
      age: "",
      region: "EU",
      platform: "PC",
      role: "Main Player",
      rank: "Grand Champion 1",
      rl_tracker: "",
      teammates: "",
    });
    setSubmitting(false);
  };

  return (
    <>
      <Seo
        title="Tryouts — Apply to NOMAX Esports"
        description="GC1+ Rocket League tryouts on PC, PS5 and Xbox. EU only, 3v3 format. Apply for Main, Substitute or Coach spots."
        path="/tryouts"
      />
      <PageHero
        eyebrow="Tryouts · 2026"
        title="Apply to NOMAX"
        description="GC1+ EU players only. 3v3 format on PC, PS5 or Xbox."
      />
      <section className="container pt-4">
        <div className="grid sm:grid-cols-3 gap-3 text-xs uppercase tracking-widest">
          {[
            { Icon: Trophy, label: "Min. Rank", value: "GC1+" },
            { Icon: Globe2, label: "Region", value: "EU Only" },
            { Icon: Gamepad2, label: "Platforms", value: "PC · PS5 · Xbox" },
          ].map(({ Icon, label, value }) => (
            <div key={label} className="flex items-center gap-3 border border-border bg-card/60 px-4 py-3 clip-corner">
              <Icon className="w-4 h-4 text-neon-blue" />
              <div>
                <div className="text-[10px] text-muted-foreground">{label}</div>
                <div className="text-foreground font-semibold">{value}</div>
              </div>
            </div>
          ))}
        </div>
      </section>
      <section className="container py-12 max-w-3xl">
        <div className="mb-6 flex items-start gap-3 border border-neon-blue/30 bg-card/60 clip-corner p-5">
          <Users className="w-5 h-5 text-neon-blue mt-0.5" />
          <div className="text-sm text-muted-foreground">
            Format: <span className="text-foreground font-semibold">3v3 Standard</span>. Bring your trio or apply solo
            to be matched. We run scrims, qualifiers and open tournaments — be ready to commit time and improve.
          </div>
        </div>
        <form onSubmit={submit} className="bg-card border border-border clip-corner p-8 md:p-10 space-y-5">
          <div className="grid sm:grid-cols-2 gap-5">
            <div>
              <label className="block text-xs uppercase tracking-widest text-muted-foreground mb-2">Email</label>
              <input
                type="email"
                className={inputCls}
                maxLength={255}
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
              />
            </div>
            <div>
              <label className="block text-xs uppercase tracking-widest text-muted-foreground mb-2">Age</label>
              <input
                type="number"
                min={13}
                max={99}
                className={inputCls}
                value={form.age}
                onChange={(e) => setForm({ ...form, age: e.target.value })}
              />
            </div>
          </div>
          <div className="grid sm:grid-cols-2 gap-5">
            <div>
              <label className="block text-xs uppercase tracking-widest text-muted-foreground mb-2">Applying As</label>
              <select
                className={inputCls}
                value={form.role}
                onChange={(e) => setForm({ ...form, role: e.target.value as typeof form.role })}
              >
                <option>Main Player</option>
                <option>Substitute</option>
                <option>Coach</option>
              </select>
            </div>
            <div>
              <label className="block text-xs uppercase tracking-widest text-muted-foreground mb-2">Platform</label>
              <select
                className={inputCls}
                value={form.platform}
                onChange={(e) => setForm({ ...form, platform: e.target.value as typeof form.platform })}
              >
                <option>PC</option>
                <option>PS5</option>
                <option>Xbox</option>
              </select>
            </div>
          </div>
          <div className="grid sm:grid-cols-2 gap-5">
            <div>
              <label className="block text-xs uppercase tracking-widest text-muted-foreground mb-2">
                Current Rank (GC1+)
              </label>
              <select
                className={inputCls}
                value={form.rank}
                onChange={(e) => setForm({ ...form, rank: e.target.value })}
              >
                <option>Supersonic Legend</option>
                <option>Grand Champion 3</option>
                <option>Grand Champion 2</option>
                <option>Grand Champion 1</option>
                <option>Other</option>
              </select>
            </div>
            <div>
              <label className="block text-xs uppercase tracking-widest text-muted-foreground mb-2">
                Region (EU only)
              </label>
              <input
                type="text"
                className={inputCls}
                maxLength={50}
                value={form.region}
                onChange={(e) => setForm({ ...form, region: e.target.value })}
                placeholder="EU country (e.g. Spain)"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs uppercase tracking-widest text-muted-foreground mb-2">RL Tracker URL</label>
            <input
              type="url"
              placeholder="https://rocketleague.tracker.network/..."
              className={inputCls}
              maxLength={500}
              value={form.rl_tracker}
              onChange={(e) => setForm({ ...form, rl_tracker: e.target.value })}
            />
          </div>
          <div>
            <label className="block text-xs uppercase tracking-widest text-muted-foreground mb-2">
              Teammates (if any)
            </label>
            <textarea
              rows={4}
              maxLength={1000}
              placeholder="Names / IGNs / trackers of who you'll play with. Leave blank if you want to be matched."
              className={inputCls}
              value={form.teammates}
              onChange={(e) => setForm({ ...form, teammates: e.target.value })}
            />
          </div>
          <button
            type="submit"
            disabled={submitting}
            className="inline-flex items-center gap-2 bg-neon-orange text-accent-foreground px-8 py-3.5 font-display font-bold uppercase tracking-widest text-sm clip-corner shadow-neon-orange hover:scale-105 transition-transform disabled:opacity-60 disabled:hover:scale-100"
          >
            {submitting ? "Sending..." : "Submit Application"} <Send className="w-4 h-4" />
          </button>
        </form>
      </section>
    </>
  );
};

export default Tryouts;
