import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";

type Status = "loading" | "valid" | "used" | "invalid" | "success" | "error";

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL as string;
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY as string;

export default function Unsubscribe() {
  const [params] = useSearchParams();
  const token = params.get("token") || "";
  const [status, setStatus] = useState<Status>("loading");
  const [email, setEmail] = useState<string>("");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!token) {
      setStatus("invalid");
      return;
    }
    (async () => {
      try {
        const res = await fetch(
          `${SUPABASE_URL}/functions/v1/handle-email-unsubscribe?token=${encodeURIComponent(token)}`,
          { headers: { apikey: SUPABASE_ANON_KEY } }
        );
        const data = await res.json().catch(() => ({}));
        if (res.ok && data?.valid) {
          setEmail(data.email || "");
          setStatus(data.used ? "used" : "valid");
        } else {
          setStatus("invalid");
        }
      } catch {
        setStatus("invalid");
      }
    })();
  }, [token]);

  const confirm = async () => {
    setSubmitting(true);
    const { data, error } = await supabase.functions.invoke("handle-email-unsubscribe", {
      body: { token },
    });
    setSubmitting(false);
    if (error || !data?.success) setStatus("error");
    else setStatus("success");
  };

  return (
    <main className="min-h-[70vh] flex items-center justify-center px-6 py-20">
      <div className="w-full max-w-md rounded-lg border border-primary/20 bg-card p-8 shadow-lg">
        <h1 className="font-display uppercase tracking-wider text-2xl text-foreground mb-4">
          Email preferences
        </h1>

        {status === "loading" && (
          <p className="text-muted-foreground">Verifying your link…</p>
        )}

        {status === "valid" && (
          <>
            <p className="text-muted-foreground mb-6">
              Unsubscribe <span className="text-foreground">{email}</span> from NOMAX emails?
            </p>
            <Button onClick={confirm} disabled={submitting} className="w-full">
              {submitting ? "Unsubscribing…" : "Confirm Unsubscribe"}
            </Button>
          </>
        )}

        {status === "used" && (
          <p className="text-muted-foreground">
            <span className="text-foreground">{email}</span> is already unsubscribed.
          </p>
        )}

        {status === "success" && (
          <p className="text-muted-foreground">
            You've been unsubscribed. We're sorry to see you go.
          </p>
        )}

        {status === "invalid" && (
          <p className="text-muted-foreground">
            This unsubscribe link is invalid or expired.
          </p>
        )}

        {status === "error" && (
          <p className="text-destructive">
            Something went wrong. Please try again later.
          </p>
        )}
      </div>
    </main>
  );
}