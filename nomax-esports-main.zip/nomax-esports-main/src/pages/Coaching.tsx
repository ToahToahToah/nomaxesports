import { ExternalLink } from "lucide-react";
import { PageHero } from "@/components/PageHero";
import { Button } from "@/components/ui/button";

export default function Coaching() {
  return (
    <div>
      <PageHero
        eyebrow="Coaching"
        title="Level Up Your Game"
        description="Get personalized Rocket League coaching from experienced players."
      />
      <section className="container py-20">
        <div className="max-w-2xl mx-auto text-center space-y-8">
          <p className="text-muted-foreground text-lg">
            Ready to rank up? Our coaching platform helps you analyze replays, improve mechanics,
            and master game sense with tailored guidance.
          </p>
          <a
            href="https://assistant.nomax.team"
            target="_blank"
            rel="noreferrer"
          >
            <Button size="lg" className="font-display uppercase tracking-wider gap-2">
              Start Coaching <ExternalLink className="w-4 h-4" />
            </Button>
          </a>
        </div>
      </section>
    </div>
  );
}
