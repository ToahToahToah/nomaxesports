import { Link } from "react-router-dom";
import { ArrowRight, Users, ShoppingBag, Heart, Calendar, Trophy, Newspaper, Printer, Send, Handshake, Lock } from "lucide-react";
import heroBg from "@/assets/hero-bg.jpg";
import { SectionHeader } from "@/components/SectionHeader";
import { Seo } from "@/components/Seo";

const internalCards = [
  { to: "/roster", icon: Users, title: "Roster", desc: "Meet the players carrying the NOMAX colors into competition." },
  { to: "/partners", icon: Handshake, title: "Partners", desc: "The brands fueling the org. Become one of them." },
];

const externalCards = [
  { href: "https://merch.nomax.team", icon: ShoppingBag, title: "Shop", desc: "Custom 3D-printed accessories, jerseys and gear." },
];

const matches = [
  { date: "Soon", event: "Open Circuit Qualifier", opponent: "TBA", status: "upcoming" as const },
  { date: "Soon", event: "Spanish Showmatch", opponent: "TBA", status: "upcoming" as const },
  { date: "—", event: "First Result Pending", opponent: "—", status: "result" as const },
];

const newsTeasers = [
  { tag: "Announcement", title: "NOMAX Esports launches", date: "May 2026" },
  { tag: "Signing", title: "Team A roster reveal incoming", date: "Coming Soon" },
  { tag: "Tournament", title: "First open circuit appearance", date: "Coming Soon" },
];

const Index = () => (
  <>
    <Seo
      title="NOMAX Esports — Spanish Rocket League Team"
      description="NOMAX Esports — Compete. Create. Dominate. Spanish Rocket League organization powered by NOMAX 3D Printing."
      path="/"
    />
    <section className="relative min-h-screen flex items-center overflow-hidden border-b border-border">
      <img src={heroBg} alt="" width={1920} height={1080} loading="eager" fetchPriority="high" decoding="async" className="absolute inset-0 w-full h-full object-cover opacity-40" />
      <div className="absolute inset-0 bg-gradient-to-b from-background/70 via-background/50 to-background" />
      <div className="absolute inset-0 pointer-events-none" aria-hidden>
        <div className="absolute -top-40 left-1/2 -translate-x-1/2 w-[900px] h-[900px] rounded-full opacity-40"
          style={{ background: "radial-gradient(circle, hsl(var(--neon-blue) / 0.45), transparent 60%)", filter: "blur(60px)" }} />
        <div className="absolute left-0 right-0 h-px bg-neon-blue/40 animate-scan" />
      </div>
      <div className="container relative z-10 py-32 md:py-40 text-center md:text-left">
        <div className="text-neon-blue uppercase tracking-[0.5em] text-[11px] font-semibold mb-8 animate-fade-in">// Rocket League · Spain · EST. 2026</div>
        <h1 className="font-display font-black text-7xl sm:text-8xl md:text-[11rem] uppercase leading-[0.9] animate-fade-in">
          NO<span className="text-neon-blue animate-pulse-glow text-glow-strong">MAX</span>
        </h1>
        <div className="font-display text-3xl md:text-5xl mt-4 tracking-[0.3em] font-bold animate-fade-in opacity-90" style={{ animationDelay: "0.15s" }}>
          ESPORTS
        </div>
        <p className="mt-10 text-2xl md:text-4xl font-display font-bold tracking-wide animate-fade-in" style={{ animationDelay: "0.3s" }}>
          <span className="text-neon-blue text-glow-blue">Compete.</span>{" "}
          <span className="text-foreground">Create.</span>{" "}
          <span className="text-neon-blue text-glow-strong">Dominate.</span>
        </p>
        <p className="mt-5 text-base md:text-lg text-muted-foreground tracking-wide max-w-xl mx-auto md:mx-0 animate-fade-in" style={{ animationDelay: "0.4s" }}>
          Spanish Rocket League Organization · Powered by <span className="text-foreground font-semibold">NOMAX 3D Printing</span>
        </p>
        <div className="mt-12 flex flex-wrap justify-center md:justify-start gap-3 animate-fade-in" style={{ animationDelay: "0.45s" }}>
          <Link to="/roster" className="btn-neon inline-flex items-center gap-2 px-7 py-4 font-display font-bold uppercase tracking-widest text-xs clip-corner">
            <Users className="w-4 h-4" /> View Roster
          </Link>
          <Link to="/tryouts" className="btn-neon inline-flex items-center gap-2 px-7 py-4 font-display font-bold uppercase tracking-widest text-xs clip-corner">
            <Send className="w-4 h-4" /> Apply for Tryouts
          </Link>
          <a href="https://merch.nomax.team" target="_blank" rel="noreferrer" className="btn-ghost-neon inline-flex items-center gap-2 px-7 py-4 font-display font-bold uppercase tracking-widest text-xs clip-corner">
            <ShoppingBag className="w-4 h-4" /> Visit Shop
          </a>
          <Link to="/support" className="btn-ghost-neon inline-flex items-center gap-2 px-7 py-4 font-display font-bold uppercase tracking-widest text-xs clip-corner">
            <Heart className="w-4 h-4" /> Support Us
          </Link>
        </div>
        <div className="mt-6 flex justify-center md:justify-start animate-fade-in" style={{ animationDelay: "0.55s" }}>
          <Link
            to="/player-room"
            className="inline-flex items-center gap-2 px-4 py-2 text-[10px] font-display font-bold uppercase tracking-[0.25em] text-neon-blue/90 border border-neon-blue/40 hover:border-neon-blue hover:text-neon-blue hover:shadow-neon-blue clip-corner transition-all"
          >
            <Lock className="w-3 h-3" /> Player Room
          </Link>
        </div>
      </div>
    </section>

    <section className="container py-20 md:py-28">
      <SectionHeader eyebrow="Explore" title="Enter the Arena" />
      <div className="grid md:grid-cols-3 gap-6">
        {internalCards.map((c) => (
          <Link key={c.to} to={c.to} className="group relative block bg-card border border-border p-8 clip-corner overflow-hidden hover:border-neon-blue transition-all">
            <div className="absolute -top-20 -right-20 w-40 h-40 rounded-full opacity-0 group-hover:opacity-30 transition-opacity"
              style={{ background: "hsl(var(--neon-blue))", filter: "blur(60px)" }} />
            <c.icon className="w-10 h-10 text-neon-blue" />
            <h3 className="font-display text-2xl font-bold uppercase mt-6 tracking-wider">{c.title}</h3>
            <p className="mt-3 text-muted-foreground">{c.desc}</p>
            <div className="mt-6 flex items-center gap-2 text-sm uppercase font-semibold tracking-widest text-neon-blue">
              Enter <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </Link>
        ))}
        {externalCards.map((c) => (
          <a key={c.href} href={c.href} target="_blank" rel="noreferrer" className="group relative block bg-card border border-border p-8 clip-corner overflow-hidden hover:border-neon-blue transition-all">
            <div className="absolute -top-20 -right-20 w-40 h-40 rounded-full opacity-0 group-hover:opacity-30 transition-opacity"
              style={{ background: "hsl(var(--neon-blue))", filter: "blur(60px)" }} />
            <c.icon className="w-10 h-10 text-neon-blue" />
            <h3 className="font-display text-2xl font-bold uppercase mt-6 tracking-wider">{c.title}</h3>
            <p className="mt-3 text-muted-foreground">{c.desc}</p>
            <div className="mt-6 flex items-center gap-2 text-sm uppercase font-semibold tracking-widest text-neon-blue">
              Enter <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </a>
        ))}
      </div>
    </section>

    <section className="container pb-8">
      <SectionHeader eyebrow="Story" title="Built in Spain. Engineered to win." />
      <div className="max-w-3xl mx-auto text-center text-foreground/80 text-lg leading-relaxed">
        NOMAX Esports is the competitive arm of <span className="text-neon-blue font-semibold">NOMAX 3D Printing</span> — a Spanish brand turning real engineering into competitive performance. We develop Rocket League talent from grassroots ranks to the open circuit, backed by custom-engineered gear and a brand built for the next generation of esports.
      </div>
    </section>

    <section className="container py-20">
      <SectionHeader eyebrow="Schedule" title="Matches & Results" />
      <div className="grid md:grid-cols-3 gap-4">
        {matches.map((m, i) => (
          <div key={i} className="bg-card border border-border clip-corner p-6 hover:border-neon-blue transition-colors">
            <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-neon-blue">
              {m.status === "upcoming" ? <Calendar className="w-4 h-4" /> : <Trophy className="w-4 h-4" />}
              {m.status === "upcoming" ? "Upcoming" : "Result"}
            </div>
            <div className="mt-4 font-display text-xl font-bold uppercase tracking-wide">{m.event}</div>
            <div className="mt-1 text-sm text-muted-foreground">vs {m.opponent}</div>
            <div className="mt-4 text-xs uppercase tracking-widest text-foreground/60">{m.date}</div>
          </div>
        ))}
      </div>
    </section>

    <section className="container pb-20">
      <div className="grid md:grid-cols-2 gap-6 items-stretch">
        <div className="relative bg-card border border-border clip-corner p-10 overflow-hidden">
          <div className="absolute inset-0 opacity-20" style={{ background: "var(--gradient-glow)" }} />
          <div className="relative">
            <div className="text-neon-blue uppercase tracking-[0.3em] text-xs font-semibold mb-3 inline-flex items-center gap-2"><Printer className="w-4 h-4" /> // Merch</div>
            <h3 className="font-display text-3xl font-black uppercase">3D-printed gear. Real performance.</h3>
            <p className="mt-3 text-muted-foreground max-w-md">Controller mounts, custom accessories, jerseys, and team drops — engineered and printed in Spain.</p>
            <a href="https://merch.nomax.team" target="_blank" rel="noreferrer" className="mt-6 inline-flex items-center gap-2 bg-neon-blue text-primary-foreground px-6 py-3 font-display font-bold uppercase tracking-widest text-xs clip-corner shadow-neon-blue hover:scale-[1.02] transition-transform">
              Shop Now <ArrowRight className="w-4 h-4" />
            </a>
          </div>
        </div>

        <div className="relative bg-card border border-border clip-corner p-10 overflow-hidden">
          <div className="text-neon-blue uppercase tracking-[0.3em] text-xs font-semibold mb-3 inline-flex items-center gap-2"><Newspaper className="w-4 h-4" /> // Latest</div>
          <h3 className="font-display text-3xl font-black uppercase mb-5">News & Updates</h3>
          <ul className="space-y-3">
            {newsTeasers.map((n, i) => (
              <li key={i} className="flex items-start justify-between gap-4 border-t border-border pt-3 first:border-t-0 first:pt-0">
                <div>
                  <div className="text-[10px] uppercase tracking-widest text-neon-blue">{n.tag}</div>
                  <div className="font-display text-base font-bold uppercase mt-0.5">{n.title}</div>
                </div>
                <span className="text-xs text-muted-foreground whitespace-nowrap">{n.date}</span>
              </li>
            ))}
          </ul>
          <Link to="/news" className="mt-6 inline-flex items-center gap-2 text-xs uppercase tracking-widest text-neon-blue hover:underline">
            All news <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </div>
    </section>

    <section className="container pb-24">
      <div className="relative bg-card border border-border clip-corner p-10 md:p-16 overflow-hidden">
        <div className="absolute inset-0 opacity-20" style={{ background: "var(--gradient-glow)" }} />
        <div className="relative grid md:grid-cols-[1fr_auto] gap-8 items-center">
          <div>
            <div className="text-neon-blue uppercase tracking-[0.3em] text-xs font-semibold mb-3">// Recruiting Now</div>
            <h3 className="font-display text-3xl md:text-4xl font-black uppercase">Recruiting <span className="text-neon-blue">GC1+ players & coaches.</span></h3>
            <p className="mt-3 text-muted-foreground max-w-xl">Open tryouts for GC1+ players on PC, PS5 and Xbox — EU only. 3v3 format. Bring a team or get assigned. Coaches, reach out directly.</p>
          </div>
          <Link to="/contact" className="inline-flex items-center gap-2 bg-neon-blue text-primary-foreground px-8 py-4 font-display font-bold uppercase tracking-widest text-sm clip-corner shadow-neon-blue hover:scale-105 transition-transform">
            Apply Now <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </div>
    </section>
  </>
);

export default Index;
