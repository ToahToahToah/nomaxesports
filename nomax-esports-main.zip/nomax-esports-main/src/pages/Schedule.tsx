import { Calendar, Trophy } from "lucide-react";
import { PageHero } from "@/components/PageHero";
import { SectionHeader } from "@/components/SectionHeader";

const upcoming = [
  { date: "TBA", event: "Open Circuit Qualifier", opponent: "TBA" },
  { date: "TBA", event: "Spanish Showmatch", opponent: "TBA" },
  { date: "TBA", event: "Community Cup", opponent: "TBA" },
];

const results: { date: string; event: string; opponent: string; score: string }[] = [];

const Schedule = () => (
  <>
    <PageHero
      eyebrow="Calendar"
      title="Schedule & Results"
      description="Upcoming matches, qualifiers and tournament results for the NOMAX Esports roster."
    />

    <section className="container py-16">
      <SectionHeader eyebrow="Next Up" title="Upcoming Matches" />
      <div className="grid md:grid-cols-3 gap-4">
        {upcoming.map((m, i) => (
          <div key={i} className="bg-card border border-border clip-corner p-6 hover:border-neon-blue transition-colors">
            <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-neon-blue">
              <Calendar className="w-4 h-4" /> Upcoming
            </div>
            <div className="mt-4 font-display text-xl font-bold uppercase tracking-wide">{m.event}</div>
            <div className="mt-1 text-sm text-muted-foreground">vs {m.opponent}</div>
            <div className="mt-4 text-xs uppercase tracking-widest text-foreground/60">{m.date}</div>
          </div>
        ))}
      </div>
    </section>

    <section className="container pb-24">
      <SectionHeader eyebrow="Recent" title="Results" />
      {results.length === 0 ? (
        <div className="bg-card border border-border clip-corner p-10 text-center">
          <Trophy className="w-8 h-8 text-neon-blue mx-auto" />
          <div className="mt-4 font-display text-xl uppercase tracking-wider">First Result Pending</div>
          <p className="mt-2 text-muted-foreground text-sm">Our roster is forming. Results will be posted here as soon as we hit the field.</p>
        </div>
      ) : (
        <div className="grid md:grid-cols-3 gap-4">
          {results.map((m, i) => (
            <div key={i} className="bg-card border border-border clip-corner p-6">
              <div className="text-xs uppercase tracking-widest text-neon-blue">Result</div>
              <div className="mt-4 font-display text-xl font-bold uppercase">{m.event}</div>
              <div className="mt-1 text-sm text-muted-foreground">vs {m.opponent} — {m.score}</div>
              <div className="mt-4 text-xs uppercase tracking-widest text-foreground/60">{m.date}</div>
            </div>
          ))}
        </div>
      )}
    </section>
  </>
);

export default Schedule;