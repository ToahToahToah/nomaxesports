import { Link } from "react-router-dom";
import { ShoppingBag, Handshake, Users, ArrowRight, Printer, TrendingUp, Eye, Youtube, Twitch, Twitter } from "lucide-react";
import { PageHero } from "@/components/PageHero";
import { SectionHeader } from "@/components/SectionHeader";
import { Seo } from "@/components/Seo";

const sections = [
  {
    icon: ShoppingBag,
    title: "Buy Official Merch",
    desc: "Every order funds the roster. Custom 3D-printed accessories, jerseys and gear — engineered in Spain.",
    cta: "Shop Now",
    href: "https://merch.nomax.team",
    external: true,
  },
  {
    icon: Handshake,
    title: "Become a Sponsor / Partner",
    desc: "Align your brand with a transparent, fast-growing esports project with real engineering behind it.",
    cta: "Partner With Us",
    href: "/partner-apply",
    external: false,
  },
  {
    icon: Users,
    title: "Follow & Share",
    desc: "Follow @NomaxEsports on YouTube, Twitch and X. Share clips, repost matches, help us grow the EU Rocket League scene.",
    cta: "See Socials",
    href: "#socials",
    external: true,
  },
];

const why = [
  { icon: Printer, title: "3D Printing Advantage", desc: "We manufacture our own gear. Every purchase directly funds the roster." },
  { icon: TrendingUp, title: "Growing Roster", desc: "A serious competitive Rocket League team climbing the Spanish scene." },
  { icon: Eye, title: "Transparent & Passionate", desc: "Built in public. Real people, real progress, no smoke and mirrors." },
];

const Support = () => (
  <>
    <Seo
      title="Support NOMAX Esports — Buy Merch, Sponsor, Share"
      description="Help build the future of Spanish Rocket League. Buy official merch, become a sponsor, or share NOMAX Esports content."
      path="/support"
    />
    <PageHero
      eyebrow="Back the Team"
      title="Support NOMAX Esports"
      description="Help us build the future of Spanish Rocket League."
    />

    <section className="container py-20 md:py-28">
      <SectionHeader eyebrow="How" title="Ways to Support" />
      <div className="grid md:grid-cols-3 gap-6">
        {sections.map((s) => (
          <div key={s.title} className="group relative bg-card border border-border clip-corner p-8 hover:border-neon-blue transition-all flex flex-col overflow-hidden">
            <div className="absolute -top-24 -right-24 w-48 h-48 rounded-full opacity-0 group-hover:opacity-25 transition-opacity"
              style={{ background: "hsl(var(--neon-blue))", filter: "blur(70px)" }} />
            <s.icon className="w-10 h-10 text-neon-blue relative" />
            <h3 className="mt-6 font-display text-2xl font-black uppercase tracking-wider relative">{s.title}</h3>
            <p className="mt-3 text-muted-foreground relative flex-1">{s.desc}</p>
            {s.external ? (
              <a href={s.href} target="_blank" rel="noreferrer" className="mt-6 inline-flex items-center gap-2 text-xs uppercase tracking-widest font-bold text-neon-blue hover:text-glow-blue relative">
                {s.cta} <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </a>
            ) : (
              <Link to={s.href} className="mt-6 inline-flex items-center gap-2 text-xs uppercase tracking-widest font-bold text-neon-blue hover:text-glow-blue relative">
                {s.cta} <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Link>
            )}
          </div>
        ))}
      </div>
    </section>

    <section className="container pb-24">
      <SectionHeader eyebrow="Why" title="Why Support Us" />
      <div className="grid md:grid-cols-3 gap-6">
        {why.map((w) => (
          <div key={w.title} className="relative bg-card border border-border clip-corner p-8 overflow-hidden">
            <div className="absolute -top-16 -right-16 w-40 h-40 rounded-full opacity-20"
              style={{ background: "hsl(var(--neon-blue))", filter: "blur(60px)" }} />
            <w.icon className="w-9 h-9 text-neon-blue relative" />
            <h3 className="mt-5 font-display text-xl font-bold uppercase tracking-wider relative">{w.title}</h3>
            <p className="mt-3 text-muted-foreground relative">{w.desc}</p>
          </div>
        ))}
      </div>
    </section>

    <section className="container pb-24">
      <div id="socials" className="relative bg-card border border-border clip-corner p-10 md:p-14 overflow-hidden mb-10">
        <div className="absolute inset-0 opacity-15" style={{ background: "var(--gradient-glow)" }} />
        <div className="relative grid md:grid-cols-[1fr_auto] gap-6 items-center">
          <div>
            <div className="text-neon-blue uppercase tracking-[0.3em] text-xs font-semibold mb-2">// Follow Us</div>
            <h3 className="font-display text-2xl md:text-3xl font-black uppercase">@NomaxEsports</h3>
            <p className="mt-2 text-muted-foreground max-w-xl">Every follow, share and clip helps. Find us on YouTube, Twitch and X.</p>
          </div>
          <div className="flex gap-3">
            {[
              { Icon: Youtube, label: "YouTube", href: "https://www.youtube.com/@NomaxEsports" },
              { Icon: Twitch, label: "Twitch", href: "https://www.twitch.tv/nomaxesports" },
              { Icon: Twitter, label: "X", href: "https://x.com/NomaxEsports" },
            ].map(({ Icon, label, href }) => (
              <a key={label} href={href} target="_blank" rel="noreferrer" aria-label={label} className="w-12 h-12 grid place-items-center border border-border hover:border-neon-blue hover:text-neon-blue hover:shadow-neon-blue transition-all clip-corner">
                <Icon className="w-5 h-5" />
              </a>
            ))}
          </div>
        </div>
      </div>

      <div className="relative bg-card border border-neon-blue/40 clip-corner p-10 md:p-16 overflow-hidden">
        <div className="absolute inset-0 opacity-20" style={{ background: "var(--gradient-glow)" }} />
        <div className="relative text-center max-w-2xl mx-auto">
          <div className="text-neon-blue uppercase tracking-[0.3em] text-xs font-semibold mb-3">// Take Action</div>
          <h3 className="font-display text-3xl md:text-5xl font-black uppercase">Pick your path. <span className="text-neon-blue text-glow-blue">Power the team.</span></h3>
          <div className="mt-10 flex flex-wrap justify-center gap-3">
            <a href="https://merch.nomax.team" target="_blank" rel="noreferrer" className="btn-neon inline-flex items-center gap-2 px-7 py-4 font-display font-bold uppercase tracking-widest text-xs clip-corner">
              <ShoppingBag className="w-4 h-4" /> Shop Merch
            </a>
            <Link to="/partner-apply" className="btn-ghost-neon inline-flex items-center gap-2 px-7 py-4 font-display font-bold uppercase tracking-widest text-xs clip-corner">
              <Handshake className="w-4 h-4" /> Become a Sponsor
            </Link>
            <a href="https://x.com/NomaxEsports" target="_blank" rel="noreferrer" className="btn-ghost-neon inline-flex items-center gap-2 px-7 py-4 font-display font-bold uppercase tracking-widest text-xs clip-corner">
              <Users className="w-4 h-4" /> Follow @NomaxEsports
            </a>
          </div>
        </div>
      </div>
    </section>
  </>
);

export default Support;