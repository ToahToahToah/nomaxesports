import { useEffect, useRef, useState } from "react";
import { Lock, Send, Calendar, Trophy, MessageSquare, LogOut, Shield, Rocket, Swords, ArrowLeft } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { PageHero } from "@/components/PageHero";
import { Seo } from "@/components/Seo";
import { toast } from "sonner";

const ACCESS_CODE = "PlayersNomax2026Pro";
const STORAGE_KEY = "nomax_player_room_unlocked";
const NAME_KEY = "nomax_player_room_name";
const GAME_KEY = "nomax_player_room_game";

type GameId = "rocket_league" | "fortnite";

const GAMES: Record<GameId, {
  id: GameId;
  label: string;
  accent: string;
  Icon: typeof Rocket;
  schedule: { date: string; event: string; opponent: string; type: "match" | "scrim" }[];
  announcements: string[];
}> = {
  rocket_league: {
    id: "rocket_league",
    label: "Rocket League",
    accent: "GC1+ · EU competitive",
    Icon: Rocket,
    schedule: [
      { date: "TBA", event: "Open Circuit Qualifier", opponent: "TBA", type: "match" },
      { date: "TBA", event: "Spanish Showmatch", opponent: "TBA", type: "match" },
      { date: "Weekly", event: "Internal Scrim Block", opponent: "Mon · Wed · Fri · 20:00 CET", type: "scrim" },
      { date: "Weekly", event: "Roster Review", opponent: "Sun · 19:00 CET", type: "scrim" },
    ],
    announcements: [
      "Tryouts are open — share the link with EU GC1+ players you trust.",
      "Scrim blocks confirmed Mon/Wed/Fri 20:00 CET. Use the chat to coordinate replays.",
      "Drop VOD reviews and clips in chat — coaches will follow up here.",
    ],
  },
  fortnite: {
    id: "fortnite",
    label: "Fortnite",
    accent: "New division · Scouting EU",
    Icon: Swords,
    schedule: [
      { date: "TBA", event: "Cash Cup Practice", opponent: "Duo / Trio queues", type: "match" },
      { date: "TBA", event: "Internal Scrim Lobby", opponent: "Private code in chat", type: "scrim" },
      { date: "Weekly", event: "Aim & Edit Block", opponent: "Tue · Thu · 19:00 CET", type: "scrim" },
    ],
    announcements: [
      "Fortnite division is forming — recruit-ready Zero Build & Build players welcome.",
      "Post your tracker, region and preferred mode in chat to get scouted.",
      "Cash Cup prep sessions starting soon — keep an eye on the schedule.",
    ],
  },
};

interface ChatMessage {
  id: string;
  author: string;
  content: string;
  created_at: string;
  game: GameId;
}

const PlayerRoom = () => {
  const [unlocked, setUnlocked] = useState<boolean>(() => {
    if (typeof window === "undefined") return false;
    return sessionStorage.getItem(STORAGE_KEY) === "1" || localStorage.getItem(STORAGE_KEY) === "1";
  });
  const [code, setCode] = useState("");
  const [remember, setRemember] = useState(true);

  if (!unlocked) {
    return (
      <>
        <Seo
          title="Player Room — NOMAX Esports"
          description="Private NOMAX Esports player room. Access requires a team code."
          path="/player-room"
        />
        <PageHero eyebrow="Restricted" title="Player Room" description="Private area for NOMAX players, subs and staff. Enter your access code." />
        <section className="container py-16">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (code === ACCESS_CODE) {
                if (remember) localStorage.setItem(STORAGE_KEY, "1");
                else sessionStorage.setItem(STORAGE_KEY, "1");
                setUnlocked(true);
                toast.success("Access granted");
              } else {
                toast.error("Invalid access code");
              }
            }}
            className="max-w-md mx-auto bg-card border border-border clip-corner p-8 space-y-5"
          >
            <div className="flex items-center gap-3 text-neon-blue">
              <Lock className="w-5 h-5" />
              <span className="text-xs uppercase tracking-widest font-semibold">// Access Code Required</span>
            </div>
            <input
              type="password"
              autoFocus
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder="Enter team code"
              className="w-full bg-input border border-border focus:border-neon-blue focus:outline-none px-4 py-3 text-foreground placeholder:text-muted-foreground transition-colors clip-corner"
            />
            <label className="flex items-center gap-2 text-xs text-muted-foreground">
              <input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)} />
              Remember me on this device
            </label>
            <button type="submit" className="btn-neon w-full inline-flex items-center justify-center gap-2 px-6 py-3 font-display font-bold uppercase tracking-widest text-xs clip-corner">
              Enter Player Room <Send className="w-4 h-4" />
            </button>
            <p className="text-[11px] text-muted-foreground text-center">
              Don't have a code? Ask a NOMAX captain or staff member.
            </p>
          </form>
        </section>
      </>
    );
  }

  return <GameGate onLogout={() => {
    localStorage.removeItem(STORAGE_KEY);
    sessionStorage.removeItem(STORAGE_KEY);
    sessionStorage.removeItem(GAME_KEY);
    setUnlocked(false);
  }} />;
};

const GameGate = ({ onLogout }: { onLogout: () => void }) => {
  const [game, setGame] = useState<GameId | null>(() => {
    if (typeof window === "undefined") return null;
    const stored = sessionStorage.getItem(GAME_KEY);
    return stored === "rocket_league" || stored === "fortnite" ? stored : null;
  });

  if (!game) {
    return (
      <>
        <Seo
          title="Player Room — NOMAX Esports"
          description="Pick your game to enter the NOMAX player room."
          path="/player-room"
        />
        <section className="container pt-10 pb-6">
          <div className="flex items-center justify-between gap-4">
            <div>
              <div className="text-neon-blue uppercase tracking-[0.4em] text-[11px] font-semibold mb-2 inline-flex items-center gap-2">
                <Shield className="w-3.5 h-3.5" /> // Restricted Area
              </div>
              <h1 className="font-display text-4xl md:text-5xl font-black uppercase tracking-wider">
                Pick your <span className="text-neon-blue text-glow-blue">Game</span>
              </h1>
              <p className="mt-2 text-muted-foreground">Each division has its own schedule, announcements and chat.</p>
            </div>
            <button onClick={onLogout} className="inline-flex items-center gap-2 px-4 py-2 text-xs uppercase tracking-widest border border-border hover:border-neon-blue hover:text-neon-blue transition-colors clip-corner">
              <LogOut className="w-4 h-4" /> Lock Room
            </button>
          </div>
        </section>
        <section className="container pb-20 grid md:grid-cols-2 gap-6">
          {(Object.values(GAMES) as typeof GAMES[GameId][]).map((g) => (
            <button
              key={g.id}
              onClick={() => {
                sessionStorage.setItem(GAME_KEY, g.id);
                setGame(g.id);
              }}
              className="group relative bg-card border border-neon-blue/40 hover:border-neon-blue hover:shadow-neon-blue transition-all clip-corner p-8 text-left overflow-hidden"
            >
              <div className="absolute inset-0 opacity-20 pointer-events-none" style={{
                background: "radial-gradient(circle at 80% 20%, hsl(var(--neon-blue) / 0.5), transparent 65%)",
              }} />
              <div className="relative flex items-center gap-5">
                <div className="w-16 h-16 grid place-items-center bg-background/80 border border-neon-blue/50 clip-corner shadow-neon-blue shrink-0">
                  <g.Icon className="w-8 h-8 text-neon-blue" />
                </div>
                <div>
                  <div className="text-[10px] uppercase tracking-[0.3em] text-neon-blue">// Division</div>
                  <div className="font-display text-3xl font-black uppercase tracking-wider mt-1">{g.label}</div>
                  <p className="text-xs text-muted-foreground mt-2 uppercase tracking-widest">{g.accent}</p>
                </div>
              </div>
              <div className="relative mt-6 inline-flex items-center gap-2 text-[11px] uppercase tracking-widest text-neon-blue font-bold">
                Enter Room <Send className="w-3.5 h-3.5" />
              </div>
            </button>
          ))}
        </section>
      </>
    );
  }

  return (
    <PlayerRoomDashboard
      game={GAMES[game]}
      onLogout={onLogout}
      onSwitchGame={() => {
        sessionStorage.removeItem(GAME_KEY);
        setGame(null);
      }}
    />
  );
};

const PlayerRoomDashboard = ({
  game,
  onLogout,
  onSwitchGame,
}: {
  game: typeof GAMES[GameId];
  onLogout: () => void;
  onSwitchGame: () => void;
}) => {
  const [name, setName] = useState<string>(() => localStorage.getItem(NAME_KEY) ?? "");
  const [draftName, setDraftName] = useState(name);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let active = true;
    setMessages([]);
    (async () => {
      const { data, error } = await supabase
        .from("player_room_messages")
        .select("id, author, content, created_at, game")
        .eq("game", game.id)
        .order("created_at", { ascending: true })
        .limit(200);
      if (!active) return;
      if (error) {
        toast.error("Could not load chat");
        return;
      }
      setMessages((data ?? []) as ChatMessage[]);
    })();

    const channel = supabase
      .channel(`player-room-chat-${game.id}`)
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "player_room_messages", filter: `game=eq.${game.id}` },
        (payload) => {
          setMessages((prev) => [...prev, payload.new as ChatMessage]);
        }
      )
      .subscribe();

    return () => {
      active = false;
      supabase.removeChannel(channel);
    };
  }, [game.id]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = input.trim();
    if (!trimmed) return;
    if (!name) {
      toast.error("Set a display name first");
      return;
    }
    setSending(true);
    const { error } = await supabase
      .from("player_room_messages")
      .insert({ author: name.slice(0, 40), content: trimmed.slice(0, 500), game: game.id });
    setSending(false);
    if (error) {
      toast.error("Could not send");
      return;
    }
    setInput("");
  };

  const saveName = (e: React.FormEvent) => {
    e.preventDefault();
    const t = draftName.trim().slice(0, 40);
    if (!t) return;
    localStorage.setItem(NAME_KEY, t);
    setName(t);
    toast.success(`Welcome, ${t}`);
  };

  return (
    <>
      <Seo
        title={`${game.label} Player Room — NOMAX Esports`}
        description={`Private NOMAX ${game.label} player room with team chat and schedule.`}
        path="/player-room"
      />
      <section className="container pt-10 pb-6">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="text-neon-blue uppercase tracking-[0.4em] text-[11px] font-semibold mb-2 inline-flex items-center gap-2">
              <game.Icon className="w-3.5 h-3.5" /> // {game.label} Division
            </div>
            <h1 className="font-display text-4xl md:text-5xl font-black uppercase tracking-wider">
              {game.label} <span className="text-neon-blue text-glow-blue">Room</span>
            </h1>
            <p className="mt-2 text-muted-foreground">Internal hub for NOMAX {game.label} players, subs and staff.</p>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={onSwitchGame} className="inline-flex items-center gap-2 px-4 py-2 text-xs uppercase tracking-widest border border-border hover:border-neon-blue hover:text-neon-blue transition-colors clip-corner">
              <ArrowLeft className="w-4 h-4" /> Switch Game
            </button>
            <button onClick={onLogout} className="inline-flex items-center gap-2 px-4 py-2 text-xs uppercase tracking-widest border border-border hover:border-neon-blue hover:text-neon-blue transition-colors clip-corner">
              <LogOut className="w-4 h-4" /> Lock Room
            </button>
          </div>
        </div>
      </section>

      <section className="container pb-20 grid lg:grid-cols-[1.1fr_1fr] gap-6">
        {/* Schedule */}
        <div className="space-y-6">
          <div className="bg-card border border-border clip-corner p-6">
            <div className="flex items-center gap-2 text-neon-blue uppercase tracking-widest text-[11px] font-semibold mb-4">
              <Calendar className="w-4 h-4" /> {game.label} Schedule
            </div>
            <ul className="divide-y divide-border">
              {game.schedule.map((s, i) => (
                <li key={i} className="py-3 flex items-start justify-between gap-4">
                  <div className="flex items-start gap-3">
                    {s.type === "match" ? <Trophy className="w-4 h-4 text-neon-blue mt-1" /> : <Calendar className="w-4 h-4 text-foreground/60 mt-1" />}
                    <div>
                      <div className="font-display font-bold uppercase tracking-wide text-sm">{s.event}</div>
                      <div className="text-xs text-muted-foreground mt-0.5">{s.opponent}</div>
                    </div>
                  </div>
                  <span className="text-[10px] uppercase tracking-widest text-foreground/60 whitespace-nowrap">{s.date}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="bg-card border border-border clip-corner p-6">
            <div className="flex items-center gap-2 text-neon-blue uppercase tracking-widest text-[11px] font-semibold mb-4">
              <MessageSquare className="w-4 h-4" /> Announcements
            </div>
            <ul className="space-y-3">
              {game.announcements.map((a, i) => (
                <li key={i} className="text-sm text-foreground/80 border-l-2 border-neon-blue/60 pl-3">
                  {a}
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Chat */}
        <div className="bg-card border border-border clip-corner flex flex-col min-h-[520px] lg:min-h-0 lg:h-[640px]">
          <div className="px-5 py-3 border-b border-border flex items-center justify-between">
            <div className="flex items-center gap-2 text-neon-blue uppercase tracking-widest text-[11px] font-semibold">
              <MessageSquare className="w-4 h-4" /> {game.label} Chat
            </div>
            {name && (
              <span className="text-[11px] uppercase tracking-widest text-muted-foreground">
                as <span className="text-foreground">{name}</span>
              </span>
            )}
          </div>

          {!name ? (
            <form onSubmit={saveName} className="p-6 space-y-4 flex-1 flex flex-col justify-center">
              <p className="text-sm text-muted-foreground">Pick a display name to join the chat.</p>
              <input
                value={draftName}
                onChange={(e) => setDraftName(e.target.value)}
                maxLength={40}
                placeholder="e.g. Toah, Babu, CoachX"
                className="w-full bg-input border border-border focus:border-neon-blue focus:outline-none px-4 py-3 text-foreground placeholder:text-muted-foreground transition-colors clip-corner"
              />
              <button type="submit" className="btn-neon inline-flex items-center justify-center gap-2 px-6 py-3 font-display font-bold uppercase tracking-widest text-xs clip-corner">
                Join Chat
              </button>
            </form>
          ) : (
            <>
              <div ref={scrollRef} className="flex-1 overflow-y-auto px-5 py-4 space-y-3">
                {messages.length === 0 && (
                  <p className="text-sm text-muted-foreground text-center mt-10">No messages yet. Say hi 👋</p>
                )}
                {messages.map((m) => (
                  <div key={m.id} className="text-sm">
                    <div className="flex items-baseline gap-2">
                      <span className="font-display font-bold uppercase tracking-wide text-neon-blue text-[11px]">{m.author}</span>
                      <span className="text-[10px] text-muted-foreground">{new Date(m.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span>
                    </div>
                    <div className="text-foreground/90 mt-0.5 whitespace-pre-wrap break-words">{m.content}</div>
                  </div>
                ))}
              </div>
              <form onSubmit={sendMessage} className="border-t border-border p-3 flex gap-2">
                <input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  maxLength={500}
                  placeholder="Message the team…"
                  className="flex-1 bg-input border border-border focus:border-neon-blue focus:outline-none px-3 py-2 text-foreground placeholder:text-muted-foreground transition-colors clip-corner text-sm"
                />
                <button type="submit" disabled={sending || !input.trim()} className="btn-neon inline-flex items-center gap-2 px-4 py-2 font-display font-bold uppercase tracking-widest text-[11px] clip-corner disabled:opacity-50">
                  <Send className="w-4 h-4" />
                </button>
              </form>
            </>
          )}
        </div>
      </section>
    </>
  );
};

export default PlayerRoom;
