import { useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { Send } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { PageHero } from "@/components/PageHero";

const schema = z.object({
  email: z.string().trim().email("Invalid email").max(255),
  website: z.string().trim().url("Must be a valid URL").max(500),
  reason: z.string().trim().min(10, "Tell us a bit more").max(2000),
});

const inputCls =
  "w-full bg-input border border-border focus:border-neon-orange focus:outline-none px-4 py-3 text-foreground placeholder:text-muted-foreground transition-colors clip-corner";

const PartnerApply = () => {
  const [form, setForm] = useState({ email: "", website: "", reason: "" });
  const [submitting, setSubmitting] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = schema.safeParse(form);
    if (!parsed.success) {
      toast.error(parsed.error.issues[0].message);
      return;
    }
    setSubmitting(true);
    const { email, website, reason } = parsed.data;
    const { error: dbError } = await supabase.from("partner_applications").insert({ email, website, reason });
    if (dbError) {
      toast.error("Could not submit. Try again.");
      setSubmitting(false);
      return;
    }
    await supabase.functions.invoke("send-application-email", {
      body: { type: "partner", payload: parsed.data },
    });
    toast.success("Inquiry received. We'll reach out soon.");
    setForm({ email: "", website: "", reason: "" });
    setSubmitting(false);
  };

  return (
    <>
      <PageHero eyebrow="Partners" title="Partner With Us" description="Tell us about your brand and let's build something together." />
      <section className="container py-16 max-w-3xl">
        <form onSubmit={submit} className="bg-card border border-border clip-corner p-8 md:p-10 space-y-5">
          <div>
            <label className="block text-xs uppercase tracking-widest text-muted-foreground mb-2">Contact Email</label>
            <input type="email" className={inputCls} maxLength={255} value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          </div>
          <div>
            <label className="block text-xs uppercase tracking-widest text-muted-foreground mb-2">Your Website</label>
            <input type="url" placeholder="https://yourbrand.com" className={inputCls} maxLength={500} value={form.website} onChange={(e) => setForm({ ...form, website: e.target.value })} />
          </div>
          <div>
            <label className="block text-xs uppercase tracking-widest text-muted-foreground mb-2">Why partner with NOMAX?</label>
            <textarea rows={6} maxLength={2000} className={inputCls} value={form.reason} onChange={(e) => setForm({ ...form, reason: e.target.value })} />
          </div>
          <button type="submit" disabled={submitting} className="inline-flex items-center gap-2 bg-neon-blue text-primary-foreground px-8 py-3.5 font-display font-bold uppercase tracking-widest text-sm clip-corner shadow-neon-blue hover:bg-neon-orange hover:shadow-neon-orange transition-all disabled:opacity-60">
            {submitting ? "Sending..." : "Submit Inquiry"} <Send className="w-4 h-4" />
          </button>
        </form>
      </section>
    </>
  );
};

export default PartnerApply;