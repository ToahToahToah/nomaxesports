import { Link } from "react-router-dom";
import { ArrowRight, Trophy, UserPlus, Headphones, Crown, Gamepad2, Globe2, Clock, Target, Sparkles, Rocket, Swords } from "lucide-react";
import { PageHero } from "@/components/PageHero";
import { SectionHeader } from "@/components/SectionHeader";
import { Seo } from "@/components/Seo";
import brokenImg from "@/assets/broken.png";
import toahImg from "@/assets/toah.jpg";
import sosarImg from "@/assets/sosarlclipsontt.png";
import domImg from "@/assets/dom.png";
import notLivelyImg from "@/assets/notlively333.png";
import zephImg from "@/assets/zeph.png";
import octopusImg from "@/assets/octopus.png";
import roxukoxuImg from "@/assets/roxukoxu.png";
import sinnasivarubanImg from "@/assets/sinnasivaruban.png";

const buildRoles = (rank: string, scrim: string) => [
  {
    icon: Crown,
    title: "Captain",
    rank,
    desc: "Team leader. Calls shots in-game, manages scrim schedules and represents NOMAX in competitions.",
    requirements: [`${rank} EU verified`, "Leadership & shot-calling", `${scrim} scrim nights / week`],
    slots: "1 Spot",
  },
  {
    icon: Trophy,
    title: "Main Player",
    rank,
    desc: "Starting roster. Compete in scrims, qualifiers and tournaments under the NOMAX banner.",
    requirements: [`${rank} EU verified`, "Mic & stable connection", `${scrim} scrim nights / week`],
    slots: "1 Spot",
  },
  {
    icon: Trophy,
    title: "Main Player",
    rank,
    desc: "Starting roster. Compete in scrims, qualifiers and tournaments under the NOMAX banner.",
    requirements: [`${rank} EU verified`, "Mic & stable connection", `${scrim} scrim nights / week`],
    slots: "1 Spot",
  },
  {
    icon: UserPlus,
    title: "Substitute",
    rank,
    desc: "Step in for scrims, qualifiers and last-minute swaps. Earn your way into the starting trio.",
    requirements: [`${rank} EU verified`, "Flexible availability", "Team-first mindset"],
    slots: "1 Spot",
  },
  {
    icon: Headphones,
    title: "Coach",
    rank: "Experienced",
    desc: "Analytical coach to lead VOD reviews, drills and prep. Proven competitive experience required.",
    requirements: ["Past competitive coaching", "VOD review workflow", "EU timezone"],
    slots: "1 Spot",
  },
];

const removeFilledRoles = (roles: ReturnType<typeof buildRoles>, players: { role: string }[] = []) => {
  const remaining = [...roles];
  for (const p of players) {
    const idx = remaining.findIndex((r) => r.title.toLowerCase() === p.role.toLowerCase());
    if (idx !== -1) remaining.splice(idx, 1);
  }
  return remaining;
};

const rocketLeagueTeams = [
  {
    name: "Team A",
    rank: "GC1–SSL",
    tagline: "Top tier · Tournament squad",
    roles: buildRoles("GC1+", "6+"),
    players: [
      { handle: "Broken", role: "Captain", rank: "GC1", img: brokenImg },
      { handle: "Sosarlclipsontt", role: "Main Player", rank: "GC1", img: sosarImg },
      { handle: "NotLively333", role: "Main Player", rank: "GC1", img: notLivelyImg },
      { handle: "Octopus", role: "Substitute", rank: "GC1", img: octopusImg },
    ],
  },
  {
    name: "Team B",
    rank: "C2–C3",
    tagline: "Competitive squad · Climbing tier",
    roles: buildRoles("GC2", "5+"),
    players: [
      { handle: "Ðom ヅ", role: "Captain", rank: "C2–C3", img: domImg },
      { handle: "Zeph", role: "Main Player", rank: "C2–C3", img: zephImg },
      { handle: "Octopus", role: "Main Player", rank: "C2–C3", img: octopusImg },
    ],
  },
  {
    name: "Team C",
    rank: "Any Rank",
    tagline: "Academy squad · Open to all ranks",
    roles: [],
    unlimited: true,
    players: [
      { handle: "roxukoxu", role: "Academy", rank: "Any", img: roxukoxuImg },
      { handle: "sinnasivaruban", role: "Academy", rank: "Any", img: sinnasivarubanImg },
    ],
  },
];

const fortniteTeams: typeof rocketLeagueTeams = [];

const founders = [
  { handle: "Toah", title: "Co-Founder", img: toahImg },
  { handle: "Babu", title: "Co-Founder" },
];

const Roster = () => (
  <>
    <Seo
      title="NOMAX Roster — Recruiting Rocket League Players"
      description="NOMAX Esports is recruiting GC1+ Rocket League players (PC, PS5, Xbox) across the EU. Apply for tryouts now."
      path="/roster"
    />
    <PageHero
      eyebrow="Squad · 2026"
      title="Building Our Roster"
      description="We are actively recruiting GC1+ players on PC, PS5 and Xbox — EU only. Compete, create and grow with NOMAX."
    />
    <section className="container pt-4 pb-2">
      <div className="flex flex-wrap items-center justify-center gap-3 text-xs uppercase tracking-widest">
        <span className="inline-flex items-center gap-2 border border-neon-blue/40 bg-card/60 px-4 py-2 clip-corner text-neon-blue">
          <Gamepad2 className="w-4 h-4" /> PC · PS5 · Xbox
        </span>
        <span className="inline-flex items-center gap-2 border border-border bg-card/60 px-4 py-2 clip-corner text-foreground/80">
          <Globe2 className="w-4 h-4" /> EU Only
        </span>
        <span className="inline-flex items-center gap-2 border border-border bg-card/60 px-4 py-2 clip-corner text-foreground/80">
          <Trophy className="w-4 h-4 text-neon-blue" /> GC1+ Required
        </span>
      </div>
    </section>
    <section className="container pt-16 pb-4">
      <SectionHeader eyebrow="Leadership" title="Founders" />
      <div className="grid sm:grid-cols-2 gap-6 max-w-3xl mx-auto">
        {founders.map((f) => (
          <div key={f.handle} className="group relative bg-card border border-neon-blue/40 clip-corner overflow-hidden hover:border-neon-blue transition-all p-8 flex items-center gap-5">
            <div className="absolute inset-0 opacity-20 pointer-events-none" style={{
              backgroundImage: "radial-gradient(circle at 80% 20%, hsl(var(--neon-blue) / 0.4), transparent 60%)",
            }} />
            <div className="relative w-16 h-16 bg-background/80 border border-neon-blue/50 clip-corner shadow-neon-blue shrink-0 overflow-hidden">
              {f.img ? (
                <img src={f.img} alt={`${f.handle} profile`} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full grid place-items-center">
                  <Sparkles className="w-7 h-7 text-neon-blue" />
                </div>
              )}
            </div>
            <div className="relative">
              <div className="text-[10px] uppercase tracking-[0.3em] text-neon-blue">{f.title}</div>
              <div className="font-display text-3xl font-black uppercase tracking-wider mt-1">{f.handle}</div>
              <p className="text-xs text-muted-foreground mt-2 uppercase tracking-widest">NOMAX Esports</p>
            </div>
          </div>
        ))}
      </div>
      <p className="text-center text-sm text-muted-foreground mt-6 max-w-xl mx-auto">
        Toah & Babu founded NOMAX Esports. They lead the organization off the pitch — separate from the competitive playing rosters below.
      </p>
    </section>
    <section className="container py-20 md:py-28">
      <SectionHeader eyebrow="Open Positions" title="Now Recruiting" />
      <div className="grid lg:grid-cols-2 gap-10 lg:gap-12">
        {/* Rocket League column */}
        <div className="space-y-12">
          <div className="flex items-center gap-3 border-b-2 border-neon-blue/60 pb-4">
            <div className="w-12 h-12 grid place-items-center bg-background border border-neon-blue/60 clip-corner shadow-neon-blue">
              <Rocket className="w-6 h-6 text-neon-blue" />
            </div>
            <div>
              <div className="text-neon-blue uppercase tracking-[0.3em] text-[10px] font-semibold">// Game</div>
              <h2 className="font-display text-2xl md:text-3xl font-black uppercase tracking-wider">Rocket League</h2>
            </div>
          </div>
          {rocketLeagueTeams.map((team) => (
            <div key={team.name} className="space-y-6">
          <div className="flex flex-wrap items-end justify-between gap-4 border-b border-border pb-4">
            <div>
              <div className="text-neon-blue uppercase tracking-[0.3em] text-xs font-semibold">// {team.tagline}</div>
              <h3 className="font-display text-3xl md:text-4xl font-black uppercase tracking-wider mt-2">
                {team.name} <span className="text-neon-blue">· {team.rank}</span>
              </h3>
            </div>
            <span className="inline-flex items-center gap-2 border border-neon-blue/40 bg-card/60 px-4 py-2 clip-corner text-neon-blue text-xs uppercase tracking-widest">
              <Trophy className="w-4 h-4" /> {team.rank} Roster
            </span>
          </div>
          {team.players && team.players.length > 0 && (
            <div className="grid sm:grid-cols-2 gap-6">
              {team.players.map((p) => (
                <div key={`${team.name}-player-${p.handle}`} className="group relative bg-card border border-neon-blue/60 clip-corner overflow-hidden hover:shadow-neon-blue transition-all flex items-center gap-5 p-5">
                  <div className="w-20 h-20 border border-neon-blue/50 clip-corner overflow-hidden shrink-0 bg-background/80">
                    <img src={p.img} alt={`${p.handle} profile`} className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1">
                    <div className="text-[10px] uppercase tracking-[0.3em] text-neon-blue">{p.role} · {p.rank}</div>
                    <div className="font-display text-2xl font-black uppercase tracking-wider mt-1">{p.handle}</div>
                    <div className="mt-2 inline-flex items-center gap-1.5 text-[10px] uppercase tracking-widest text-foreground/70 border border-border px-2 py-1">
                      <Sparkles className="w-3 h-3 text-neon-blue" /> Signed
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
          <div className="grid sm:grid-cols-2 gap-6">
            {removeFilledRoles(team.roles, team.players).map((r, idx) => (
              <div key={`${team.name}-${r.title}-${idx}`} className="group relative bg-card border border-border clip-corner overflow-hidden hover:border-neon-blue transition-all flex flex-col">
            <div className="relative h-44 bg-gradient-to-br from-background via-card to-background border-b border-border overflow-hidden">
              <div className="absolute inset-0 opacity-30" style={{
                backgroundImage: "radial-gradient(circle at 30% 30%, hsl(var(--neon-blue) / 0.4), transparent 60%)",
              }} />
              <div className="absolute inset-0 opacity-20" style={{
                backgroundImage: "linear-gradient(hsl(var(--neon-blue) / 0.15) 1px, transparent 1px), linear-gradient(90deg, hsl(var(--neon-blue) / 0.15) 1px, transparent 1px)",
                backgroundSize: "24px 24px",
              }} />
              <div className="absolute left-0 right-0 h-px top-1/2 bg-neon-blue/60 shadow-neon-blue" />
              <div className="absolute top-3 left-3 text-[10px] uppercase tracking-widest text-neon-blue border border-neon-blue/50 px-2 py-1 bg-background/70">
                Recruiting
              </div>
              <div className="absolute top-3 right-3 text-[10px] uppercase tracking-widest text-foreground/80 border border-border px-2 py-1 bg-background/70">
                {r.slots}
              </div>
              <div className="absolute -bottom-6 -right-6 opacity-10 group-hover:opacity-30 transition-opacity">
                <r.icon className="w-40 h-40 text-neon-blue" />
              </div>
              <div className="absolute bottom-4 left-4 flex items-center gap-3">
                <div className="w-12 h-12 grid place-items-center bg-background/80 border border-neon-blue/40 clip-corner">
                  <r.icon className="w-6 h-6 text-neon-blue" />
                </div>
                <div>
                  <div className="text-[10px] uppercase tracking-[0.3em] text-neon-blue">{r.rank}</div>
                  <div className="font-display text-xl font-black uppercase tracking-wider">{r.title}</div>
                </div>
              </div>
            </div>
            <div className="p-6 flex flex-col flex-1">
              <p className="text-muted-foreground text-sm">{r.desc}</p>
              <ul className="mt-5 space-y-2">
                {r.requirements.map((req) => (
                  <li key={req} className="flex items-start gap-2 text-sm text-foreground/85">
                    <Target className="w-3.5 h-3.5 text-neon-blue mt-1 shrink-0" />
                    <span>{req}</span>
                  </li>
                ))}
              </ul>
              <div className="mt-6 pt-5 border-t border-border flex items-center justify-between text-[11px] uppercase tracking-widest">
                <span className="inline-flex items-center gap-1.5 text-foreground/70"><Clock className="w-3.5 h-3.5 text-neon-blue" /> Open</span>
                <Link to="/tryouts" className="inline-flex items-center gap-1.5 text-neon-blue hover:text-glow-blue font-bold">
                  Apply <ArrowRight className="w-3.5 h-3.5" />
                </Link>
              </div>
            </div>
              </div>
            ))}
          </div>
            </div>
          ))}
        </div>

        {/* Fortnite column */}
        <div className="space-y-12">
          <div className="flex items-center gap-3 border-b-2 border-neon-blue/60 pb-4">
            <div className="w-12 h-12 grid place-items-center bg-background border border-neon-blue/60 clip-corner shadow-neon-blue">
              <Swords className="w-6 h-6 text-neon-blue" />
            </div>
            <div>
              <div className="text-neon-blue uppercase tracking-[0.3em] text-[10px] font-semibold">// Game</div>
              <h2 className="font-display text-2xl md:text-3xl font-black uppercase tracking-wider">Fortnite</h2>
            </div>
          </div>

          {fortniteTeams.length === 0 && (
            <div className="relative bg-card border border-neon-blue/40 clip-corner p-8 overflow-hidden">
              <div className="absolute inset-0 opacity-20 pointer-events-none" style={{
                background: "radial-gradient(circle at 70% 30%, hsl(var(--neon-blue) / 0.5), transparent 60%)",
              }} />
              <div className="relative space-y-4">
                <div className="inline-flex items-center gap-2 border border-neon-blue/50 text-neon-blue px-3 py-1.5 clip-corner text-[10px] uppercase tracking-widest">
                  <Sparkles className="w-3.5 h-3.5" /> New Division
                </div>
                <h3 className="font-display text-2xl md:text-3xl font-black uppercase tracking-wider">
                  Fortnite roster <span className="text-neon-blue">forming</span>
                </h3>
                <p className="text-sm text-muted-foreground">
                  NOMAX is expanding into Fortnite. We are scouting EU duos and trios — Zero Build & Build players welcome. Cash Cups and tournament experience a plus.
                </p>
                <ul className="space-y-2 text-sm text-foreground/85">
                  <li className="flex items-start gap-2"><Target className="w-3.5 h-3.5 text-neon-blue mt-1 shrink-0" /> EU servers · stable ping</li>
                  <li className="flex items-start gap-2"><Target className="w-3.5 h-3.5 text-neon-blue mt-1 shrink-0" /> Proven Cash Cup placements or strong arena rank</li>
                  <li className="flex items-start gap-2"><Target className="w-3.5 h-3.5 text-neon-blue mt-1 shrink-0" /> Mic, scrim availability, team-first mindset</li>
                </ul>
                <div className="pt-2">
                  <Link to="/tryouts" className="btn-neon inline-flex items-center gap-2 px-6 py-3 font-display font-bold uppercase tracking-widest text-xs clip-corner">
                    Apply for Fortnite Tryouts <ArrowRight className="w-3.5 h-3.5" />
                  </Link>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>

    <section className="container pb-24">
      <div className="relative bg-card border border-neon-blue/40 clip-corner p-10 md:p-16 overflow-hidden">
        <div className="absolute inset-0 opacity-30"
          style={{ background: "radial-gradient(circle at 80% 50%, hsl(var(--neon-blue) / 0.45), transparent 65%)" }} />
        <div className="relative text-center max-w-3xl mx-auto">
          <div className="text-neon-blue uppercase tracking-[0.3em] text-xs font-semibold mb-4">// Tryouts Open</div>
          <h3 className="font-display text-3xl md:text-5xl font-black uppercase">
            Think you have what it takes?
          </h3>
          <p className="mt-4 text-muted-foreground md:text-lg">
            Apply now and we will run <span className="text-foreground font-semibold">3v3 tryouts</span>. Bring a team or get assigned to one. EU players only — minimum rank <span className="text-neon-blue font-semibold">GC1</span> on PC, PS5 or Xbox.
          </p>
          <div className="mt-10 flex flex-wrap justify-center gap-3">
            <Link to="/tryouts" className="btn-neon inline-flex items-center gap-2 px-8 py-4 font-display font-bold uppercase tracking-widest text-sm clip-corner">
              Apply for Tryouts <ArrowRight className="w-4 h-4" />
            </Link>
            <Link to="/contact" className="btn-ghost-neon inline-flex items-center gap-2 px-8 py-4 font-display font-bold uppercase tracking-widest text-sm clip-corner">
              Contact Us <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </div>
    </section>
  </>
);

export default Roster;
