import { useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { Youtube, Twitch, Twitter, Send } from "lucide-react";
import { PageHero } from "@/components/PageHero";

const schema = z.object({
  name: z.string().trim().min(1, "Name required").max(100),
  email: z.string().trim().email("Invalid email").max(255),
  subject: z.enum(["General", "Partnership Inquiry", "Player Tryout"]),
  message: z.string().trim().min(1, "Message required").max(2000),
});

const Contact = () => {
  const [form, setForm] = useState({ name: "", email: "", subject: "General", message: "" });

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const result = schema.safeParse(form);
    if (!result.success) {
      toast.error(result.error.issues[0].message);
      return;
    }
    toast.success("Message sent. We'll be in touch.");
    setForm({ name: "", email: "", subject: "General", message: "" });
  };

  const inputCls =
    "w-full bg-input border border-border focus:border-neon-blue focus:outline-none px-4 py-3 text-foreground placeholder:text-muted-foreground transition-colors clip-corner";

  return (
    <>
      <PageHero
        eyebrow="Connect"
        title="Contact"
        description="Tryouts, partnerships, press — drop us a transmission."
      />
      <section className="container py-16 grid lg:grid-cols-[1.4fr_1fr] gap-12">
        <form onSubmit={submit} className="bg-card border border-border clip-corner p-8 md:p-10 space-y-5">
          <div>
            <label className="block text-xs uppercase tracking-widest text-muted-foreground mb-2">Name</label>
            <input
              className={inputCls}
              maxLength={100}
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
            />
          </div>
          <div>
            <label className="block text-xs uppercase tracking-widest text-muted-foreground mb-2">Email</label>
            <input
              type="email"
              className={inputCls}
              maxLength={255}
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
            />
          </div>
          <div>
            <label className="block text-xs uppercase tracking-widest text-muted-foreground mb-2">Subject</label>
            <select
              className={inputCls}
              value={form.subject}
              onChange={(e) => setForm({ ...form, subject: e.target.value })}
            >
              <option>General</option>
              <option>Partnership Inquiry</option>
              <option>Player Tryout</option>
            </select>
          </div>
          <div>
            <label className="block text-xs uppercase tracking-widest text-muted-foreground mb-2">Message</label>
            <textarea
              rows={6}
              maxLength={2000}
              className={inputCls}
              value={form.message}
              onChange={(e) => setForm({ ...form, message: e.target.value })}
            />
          </div>
          <button
            type="submit"
            className="inline-flex items-center gap-2 bg-neon-blue text-primary-foreground px-8 py-3.5 font-display font-bold uppercase tracking-widest text-sm clip-corner shadow-neon-blue hover:bg-neon-orange hover:shadow-neon-orange transition-all"
          >
            Send Transmission <Send className="w-4 h-4" />
          </button>
        </form>

        <aside className="space-y-6">
          <div className="bg-card border border-border clip-corner p-8">
            <h3 className="font-display text-xl font-bold uppercase tracking-wider">Follow the Org</h3>
            <p className="mt-2 text-sm text-muted-foreground">Catch the highlights, drops, and tryout news first.</p>
            <div className="mt-5 flex gap-3">
              {[
                { Icon: Youtube, label: "YouTube", href: "https://www.youtube.com/@NomaxEsports" },
                { Icon: Twitch, label: "Twitch", href: "https://www.twitch.tv/nomaxesports" },
              { Icon: Twitter, label: "X", href: "https://x.com/NomaxEsports" },
              ].map(({ Icon, label, href }) => (
                <a
                  key={label}
                  href={href}
                  target="_blank"
                  rel="noreferrer"
                  aria-label={label}
                  className="w-12 h-12 grid place-items-center border border-border hover:border-neon-blue hover:text-neon-blue clip-corner transition-colors"
                >
                  <Icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>
          <div className="bg-card border border-neon-orange/40 clip-corner p-8">
            <div className="text-neon-orange uppercase tracking-[0.3em] text-xs font-semibold mb-2">// Tryouts</div>
            <h3 className="font-display text-xl font-bold uppercase tracking-wider">GC3 or SSL?</h3>
            <p className="mt-2 text-sm text-muted-foreground">
              Select <span className="text-foreground font-semibold">Player Tryout</span> as the subject and tell us
              your rank, region and platform.
            </p>
          </div>
        </aside>
      </section>
    </>
  );
};

export default Contact;
